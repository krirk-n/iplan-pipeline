.onLoad <- function(libname, pkgname) {
  utils::globalVariables(c(
    "%chin%",".BY",".I",".SD",":=","ENA_DIRECTION","as.data.table","code","col2rgb",
    "color_adjusted","combn","data.table","distance","hsv","is","label","node_1","node_2",
    "prcomp","rgb2hsv","set","t.test","value","var","variable"
  ))
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("For the latest features and updates, install from https://cran.qe-libs.org");
  invisible();
}
