#' @title ona for modeling ordered networks
#' @description ona for modeling ordered networks
#' @name ona
#' @import data.table
#' @importFrom stats cor
#' @useDynLib ona, .registration = TRUE
NULL
