alpha_to_hex <- function(alpha) {
  toupper((sprintf("%02s", as.hexmode(round(alpha * 255)))))
}
lighten_color <- function(col, amt = 1, alpha = 1) {
  rgb_white <- grDevices::col2rgb("#FFFFFF");

  col_as_rgb <- if(is.character(col))
      grDevices::col2rgb(col)
    else
      col_as_rgb <- col

  # rgb_white + (rgb_just_s - rgb_white) * (this_color_hsv$alpha * edge_arrow_saturation_multiplier)
  rgb_white + (col_as_rgb - rgb_white) * (alpha * amt)
}
darken_color <- function(col, amt = 1, alpha = 1) {
  rgb_white <- grDevices::col2rgb("#FFFFFF");

  col_as_rgb <- if(is.character(col))
      grDevices::col2rgb(col)
    else
      col_as_rgb <- col

  (rgb_white + (col_as_rgb - rgb_white) * (alpha)) * (1 - -(1 - amt))
}
CreatePointByDistance <- function(P1, P2, dist = 0.1) {
  P_dist <- LearnGeom::DistancePoints(P1, P2)
  if(P_dist == 0) {
    return(P1)
  }
  else {
    d_ratio <- (P_dist - dist) / P_dist
    xt <- (1 - d_ratio) * P1[1] + (d_ratio * P2[1])
    yt <- (1 - d_ratio) * P1[2] + (d_ratio * P2[2])

    P3 <- c(xt, yt)
    names(P3) <- c("X", "Y")

    return(P3)
  }
}
MoveLineAlong <- function(x1, y1, m) {
  x <- 0
  y <- m * x - m * x1 + y1

  Line <- c(m, y)
  names(Line) = c("slope", "intercept")
  class(Line) <- append(class(Line), "Line")
  Line
}
CalculateSegmentHeight <- function(radius, chord_length) {
  (radius) - ( 0.5 * sqrt(4*(radius ^ 2) - (chord_length ^ 2)) )
}
CalculateSegmentArea <- function(radius, height) {
  ((radius ^ 2) * acos((radius - height) / radius)) -
  ((radius - height) * sqrt((2 * radius * height) - (height ^ 2)))
}
edge_fun <- function(x, fun, y = NULL) {
  if(!is.matrix(x)) {
    if (!is.vector(x)) {
      stop("x is required as matrix or vector. If it's a vector, y is required to be the same.")
    }
    else if (is.null(y)) {
      stop("If x is a vector, y is required to be a vector.")
    }
  }
  else {
    y <- x[2,]
    x <- x[1,]
  }

  do.call(fun, list(x, y))
}
edge_center <- function(x, y = NULL) {
  mid <- edge_fun(x = x, fun = LearnGeom::MidPoint, y = y);
  names(mid) <- c("x", "y")

  mid
}
node_distance <- function(x, y = NULL) {
  dist <- edge_fun(x = x, fun = LearnGeom::DistancePoints, y = y);
  names(dist) <- c("distance")
  dist
}
edge_center_weighted <- function(x, weight, toward = 1) {
  edge_line <- edge_fun(x = x, fun = LearnGeom::CreateLinePoints);
  edge_mid <- edge_center(x)
  edge_len <- node_distance(x)

  pt_wh <- ifelse(weight > 0, 1, 2)
  pt_ref <- x[toward, ]

  v_dist <- edge_len * weight;
  if(edge_line[1] == Inf) {
    int <- matrix(c(
        rep(pt_ref[1], 2),
        pt_ref[2] + v_dist,
        pt_ref[2] - v_dist
      ),
      ncol = 2)
  }
  else if (edge_line[1] == 0) {
    # stop("No edge")
    int <- matrix(c(
      pt_ref[1] + v_dist,
      pt_ref[1] - v_dist,
      rep(pt_ref[2], 2)
    ),
    ncol = 2)
  }
  else {
    if(all(abs(diff(x)) < (.Machine$double.eps ^ 0.5))) {
      int <- x;
    }
    else {
      int <- LearnGeom::IntersectLineCircle(edge_line, pt_ref, v_dist)
    }
  }
  int_dists <- apply(int, 1, node_distance, x[-toward,])

  x_sorted <- sort(x[,1])
  y_sorted <- sort(x[,2])
  on_segment <- apply(int, 1, function(p) {
    p[1] >= x_sorted[1] && p[1] <= x_sorted[2] &&
    p[2] >= y_sorted[1] && p[2] <= y_sorted[2]
  })
  if(all(on_segment)) {
    int_closest <- which(int_dists == min(int_dists))
  }
  else {
    int_closest <- which(on_segment)
  }
  w_c <- int[int_closest, ]

  w_c
}

create_edge_matrix <- function(
  set, dims = 1:2,
  weights = colMeans(as.matrix(set$line.weights)),
  nodes = set$rotation$nodes,
  direction = 1,
  node_position_multiplier = 1
) {
  raw_weights <- weights;
  weights <- abs(weights);
  weights_matrix <- to_square(weights);
  raw_weights_matrix <- to_square(raw_weights);
  rownames(weights_matrix) <- colnames(weights_matrix) <- nodes$code

  nodes[, (seq(2, ncol(nodes))) := lapply(.SD, `*`, node_position_multiplier) , .SDcols = (seq(2, ncol(nodes)))];
  nodes_xy <- nodes[, c(1, dims+1), with = F]
  colnames(nodes_xy) <- c("code", "x", "y")
  node_combinations <- combn(length(nodes_xy[[1]]), 2);

  edge_names_matrix <- t(matrix(nodes$code[node_combinations], nrow = 2))
  edge_table <- data.table::data.table(node_1 = edge_names_matrix[, 1], node_2 = edge_names_matrix[, 2])
  edge_table[, label := paste(node_1, node_2, sep = "_")]
  edge_table <- edge_table[,
    c("slope","midpoint_x", "midpoint_y", "distance", "weight", "weight_1", "weight_2", "weighted_midpoint_x", "weighted_midpoint_y", "raw_weight_1", "raw_weight_2") := {
      node_indices <- node_combinations[,.I];
      node_1 <- .SD[["node_1"]];
      node_2 <- .SD[["node_2"]];
      points <- nodes_xy[code == node_1 | code == node_2, ];
      edge_line <- edge_fun(x = as.matrix(points), fun = LearnGeom::CreateLinePoints);
      cent <- edge_center(as.matrix(points));
      distance <- node_distance(as.matrix(points));

      # browser();
      if(direction == 1) {
        weight_2 <- weights_matrix[node_indices[1], node_indices[2]];
        weight_1 <- weights_matrix[node_indices[2], node_indices[1]];
        raw_weight_2 <- raw_weights_matrix[node_indices[1], node_indices[2]];
        raw_weight_1 <- raw_weights_matrix[node_indices[2], node_indices[1]];
      }
      else {
        weight_1 <- weights_matrix[node_indices[1], node_indices[2]];
        weight_2 <- weights_matrix[node_indices[2], node_indices[1]];
        raw_weight_1 <- raw_weights_matrix[node_indices[1], node_indices[2]];
        raw_weight_2 <- raw_weights_matrix[node_indices[2], node_indices[1]];
      }
      weight_toward = ifelse(weight_2 > weight_1, 2, 1);

      # weight_diff = ifelse(weight_1 - weight_2 > 0,  (weight_1 - weight_2) / (weight_1 + weight_2), 0)
      weighted_center <- cent
      weight_diff = max(weight_1, weight_2) / (weight_1 + weight_2)
      if(!is.nan(weight_diff)) {
        if( weight_diff == 1 ) {
          if(direction == 1) {
            if(weight_toward == 1) {
              weighted_center <- as.matrix(points[2,]);
            }
            else {
              weighted_center <- as.matrix(points[1,]);
            }
          }
          else {
            if(weight_toward == 2) {
              weighted_center <- as.matrix(points[1,]);
            }
            else {
              weighted_center <- as.matrix(points[2,]);
            }
          }
        }
        else if ( abs(weight_1 - weight_2) > 0.000000001 ) {
          weighted_center <- edge_center_weighted(as.matrix(points), weight_diff, toward = weight_toward)
          if(weight_diff > 0) {
          }
        }
        else {
          # print("Why are we here?")
          # we're here b/c equal weights, but are sure about self connections?
        }
      }
      else {
        # Note: means there isn't a connection?
        # print("Why are we here too?")
      }

      list(
        slope = ifelse(edge_line[1] == "Inf", Inf, edge_line[1]),
        midpoint_x = cent[1],
        midpoint_y = cent[2],
        distance = distance,
        weight = weight_1 + weight_2,
        weight_1 = weight_1,
        weight_2 = weight_2,
        weighted_midpoint_x = weighted_center[1],
        weighted_midpoint_y = weighted_center[2],
        raw_weight_1 = raw_weight_1,
        raw_weight_2 = raw_weight_2
      )
    },
    by = seq(nrow(edge_table))
  ];

  attr(edge_table, "nodes_xy") <- nodes_xy
  attr(edge_table, "node_combinations") <- node_combinations

  edge_table
}

edge_paths <- function(x,
  edge_color = NULL, edge_end = "outward",
  edge_size_multiplier = 1,
  desaturate_edges_by = "weight", lighten_edges_by = desaturate_edges_by,
  fake_alpha = FALSE,
  scale_edges_to = c(0,1), scale_edges_from = c(0, max(x[, c("weight_1", "weight_2")])),
  path_as = "svg", edge_arrow = TRUE, edge_arrow_offset = 0.5, edge_arrow_width = 0.05,
  edge_arrow_saturation_multiplier = 0.75, edge_halo = 0.5, edge_halo_multiplier = 1.04,
  edge_arrows_to_show = "both", arrow_halo = edge_halo,
  sender_direction = 1, edge_arrow_direction = 2
) {
  edge_arrows_to_show <- match.arg(edge_arrows_to_show, c("both", "min", "max"))
  edges <- data.table::copy(x);
  edges_ <- data.table::melt(edges, measure.vars = c("weight_1", "weight_2"));
  edges_[variable == "weight_2", c("node_1", "node_2") := { list(node_2, node_1) }];

  data.table::setorder(edges, weight);
  data.table::setorder(edges_, value);

  nodes_xy <- attr(x, "nodes_xy");
  node_combinations <- attr(x, "node_combinations");

  if(is.null(edge_color)) {
    edge_color <- rep("#000000", nrow(edges_));
  }
  else if(length(edge_color) == 1) {
    edge_color <- rep(edge_color, nrow(edges_));
  }
  else if(length(edge_color) == 2) {
    edge_color <- edges_[, { ifelse(.SD[[paste0("raw_", variable)]] < 0, edge_color[2], edge_color[1]) }, by = 1:nrow(edges_)][[2]]
  }

  rgb_white <- grDevices::col2rgb("#FFFFFF", alpha = F)
  paths <- list();
  # for(e_row in seq.int(nrow(edges_))) {
  for(e_row in seq.int(nrow(edges_))) {
    edge <- edges_[e_row,]
    mid_point <- c(edge$weighted_midpoint_x, edge$weighted_midpoint_y);
    node_col <- "node_1";
    weight_col <- "value"; #ifelse(e == 1, 2, 1));

    node <- nodes_xy[code == edge[[node_col]]];
    line_xy <- matrix(c(edge$weighted_midpoint_x, node$x, edge$weighted_midpoint_y, node$y), ncol = 2);
    edge_line <- edge_fun(line_xy, fun = LearnGeom::CreateLinePoints);

    rnd <- 40;
    mp <- 1;
    weight <- edge[[weight_col]] # * edge_size_multiplier;
    if(weight > 0) { # && (mid_point != as.matrix(node))) {
      radius <- edge[[weight_col]] / 2;

      path <- list(type = "path", weight = weight, line = list( width = edge_halo, color = edge_color[e_row] )) #"#FF0000" ) )
      if(!is.null(desaturate_edges_by)) {
        this_color_hsv <- as.list(t(grDevices::rgb2hsv(grDevices::col2rgb(edge_color[e_row]))));
        names(this_color_hsv) <- c("h", "s", "v");

        if (is.function(desaturate_edges_by)) {
          this_color_hsv$s <- do.call(desaturate_edges_by, list(weight))
        }
        else if(desaturate_edges_by == "weight") {
          this_color_hsv$s <- scales::rescale(x = weight, to = scale_edges_to, from = scale_edges_from);
        }

        if(!is.null(lighten_edges_by)) {
          if (is.function(lighten_edges_by)) {
            this_color_hsv$alpha <- do.call(lighten_edges_by, list(weight))
          }
          else if(lighten_edges_by == "weight") {
            # this_color_hsv$alpha <- this_color_hsv$s;
            this_color_hsv$alpha <- weight;
          }
        }

        col_just_s <- grDevices::hsv(this_color_hsv$h, this_color_hsv$s, this_color_hsv$v)
        rgb_just_s <- col2rgb(col_just_s)

        path$opacity <- 1
        if(fake_alpha == TRUE) {
          # browser()
          # rgb_s_and_a_equiv <- rgb_white + (rgb_just_s - rgb_white) * (this_color_hsv$alpha)
          rgb_s_and_a_equiv <- lighten_color(rgb_just_s, alpha = this_color_hsv$alpha);
          rgb_s_and_a_edge <- darken_color(rgb_just_s, alpha = this_color_hsv$alpha , amt = edge_halo_multiplier);

          path$fillcolor <- grDevices::rgb(rgb_s_and_a_equiv[1,1], rgb_s_and_a_equiv[2,1], rgb_s_and_a_equiv[3,1], maxColorValue = 255)
          # browser(expr = { path$fillcolor == "#FFCFCF" })
          path$line$color <- grDevices::rgb(rgb_s_and_a_edge[1,1], rgb_s_and_a_edge[2,1], rgb_s_and_a_edge[3,1], maxColorValue = 255)
        }
        else {
          # path$opacity <- this_color_hsv$alpha
          path$fillcolor <- do.call(grDevices::hsv, this_color_hsv)
        }
      }
      else {
        path$fillcolor <- edge_color[e_row];
        rgb_just_s <- col2rgb(path$fillcolor)
        this_color_hsv <- as.list(t(grDevices::rgb2hsv(grDevices::col2rgb(edge_color[e_row]))));
        names(this_color_hsv) <- c("h", "s", "v");
        this_color_hsv$alpha <- weight;
      }

      if(edge_end == "outward") {
        rotate_on <- c(x = node$x, y = node$y);
        pinch_on <- c(edge$weighted_midpoint_x, edge$weighted_midpoint_y);
        if (edge_line[1] == 0) {
          perp_line <- LearnGeom::CreateLinePoints(c(node$x, node$y), c(node$x+0.001, 0));
        }
        else if(is.finite(edge_line[1])){
          perp_line <- LearnGeom::Rotate(edge_line, as.matrix(node), 90);
        }
        else {
          perp_line <- LearnGeom::CreateLinePoints(c(node$x, node$y), c(0.001, node$y));
        }
        perp_base <- LearnGeom::IntersectLineCircle(perp_line, as.matrix(node), radius * edge_size_multiplier);
        # Find points of circle, with center at node, that intersect along the edge line.
        # The one that is furthest from the midpoint is used as the extension for the curve
        # edge_ext <- LearnGeom::IntersectLineCircle(edge_line, as.matrix(node), edge[[weight_col]] * edge_size_multiplier);
        # ext_dist <- apply(edge_ext, 1, LearnGeom::DistancePoints, c(edge$weighted_midpoint_x, edge$weighted_midpoint_y));
        # ext_max <- which.max(ext_dist);
        # edge_ext_pt <- edge_ext[ext_max,];

        svg_curve_control_multiplier = 1.1;
        if(!is.finite(perp_line[1]) || perp_line[1] == "Inf" || perp_line[1] == Inf) {
          browser()
        }
        else if(perp_line[1] == 0) {
          perp_base_intercepts <- perp_base
          perp_base_intercepts[, 2] <- 0
          perp_line_1 <- LearnGeom::CreateLinePoints(perp_base[1,], perp_base_intercepts[1,]);
          perp_line_2 <- LearnGeom::CreateLinePoints(perp_base[2,], perp_base_intercepts[2,]);
          perp_adj <- rep((radius * svg_curve_control_multiplier) * edge_size_multiplier, 2) * c(1,-1)
          perp_line_1_ints <- matrix(perp_base[1,], nrow = 2, ncol = 2, byrow = TRUE)
          perp_line_2_ints <- matrix(perp_base[2,], nrow = 2, ncol = 2, byrow = TRUE)

          perp_line_1_ints[, 2] <- perp_line_1_ints[,2] + perp_adj
          perp_line_2_ints[, 2] <- perp_line_2_ints[,2] + perp_adj
        }
        else {
          perp_line_1 <- LearnGeom::Rotate(perp_line, perp_base[1,], 90)
          perp_line_2 <- LearnGeom::Rotate(perp_line, perp_base[2,], 90);

          perp_line_1_ints <- LearnGeom::IntersectLineCircle(perp_line_1, perp_base[1,], (radius * svg_curve_control_multiplier) * edge_size_multiplier);
          perp_line_2_ints <- LearnGeom::IntersectLineCircle(perp_line_2, perp_base[2,], (radius * svg_curve_control_multiplier) * edge_size_multiplier);
        }
        perp_line_1_dists <- apply(perp_line_1_ints, 1, LearnGeom::DistancePoints, c(edge$weighted_midpoint_x, edge$weighted_midpoint_y));
        perp_line_1_dists_max <- which.max(perp_line_1_dists);
        perp_line_1_pt <- perp_line_1_ints[perp_line_1_dists_max,];

        perp_line_2_dists <- apply(perp_line_2_ints, 1, LearnGeom::DistancePoints, c(edge$weighted_midpoint_x, edge$weighted_midpoint_y));
        perp_line_2_dists_max <- which.max(perp_line_2_dists);
        perp_line_2_pt <- perp_line_2_ints[perp_line_2_dists_max,];

        new_path <- paste0(
           "M", paste(mp * round(c(pinch_on[1], pinch_on[2]), rnd), collapse = " "),
          " L", paste(mp * round(c(perp_base[1,1], perp_base[1,2]), rnd), collapse = " "),
          " C", paste(mp * round(c(perp_line_1_pt[1], perp_line_1_pt[2]), rnd), collapse = " "), ", ",
                paste(mp * round(c(perp_line_2_pt[1], perp_line_2_pt[2]), rnd), collapse = " "), ", ",
                paste(mp * round(c(perp_base[2,1], perp_base[2,2]), rnd), collapse = " "),
          " Z"
        )
        path$path <- new_path;
        paths <- c(paths, list(path));
      }
      else if (edge_end == "inward") {
        rotate_on <- c(x = edge$weighted_midpoint_x, y = edge$weighted_midpoint_y)
        pinch_on <- c(x = node$x, y = node$y);
        if(is.finite(edge_line[1])){
          perp_line <- LearnGeom::Rotate(edge_line, as.matrix(rotate_on), 90);
        }
        else {
          perp_line <- LearnGeom::CreateLinePoints(rotate_on, c(0, rotate_on[2]));
        }
        perp_base <- LearnGeom::IntersectLineCircle(perp_line, as.matrix(rotate_on), radius * edge_size_multiplier);

        svg_curve_control_multiplier = 1.1;
        if(!is.finite(perp_line[1]) || perp_line[1] == "Inf" || perp_line[1] == Inf) {
          browser()
        }
        else if(perp_line[1] == 0) {
          perp_base_intercepts <- perp_base
          perp_base_intercepts[, 2] <- 0
          perp_line_1 <- LearnGeom::CreateLinePoints(perp_base[1,], perp_base_intercepts[1,]);
          perp_line_2 <- LearnGeom::CreateLinePoints(perp_base[2,], perp_base_intercepts[2,]);
          perp_adj <- rep((radius * svg_curve_control_multiplier) * edge_size_multiplier, 2) * c(1,-1)
          perp_line_1_ints <- matrix(perp_base[1,], nrow = 2, ncol = 2, byrow = TRUE)
          perp_line_2_ints <- matrix(perp_base[2,], nrow = 2, ncol = 2, byrow = TRUE)

          perp_line_1_ints[, 2] <- perp_line_1_ints[,2] + perp_adj
          perp_line_2_ints[, 2] <- perp_line_2_ints[,2] + perp_adj
        }
        else {
          perp_line_1 <- LearnGeom::Rotate(perp_line, perp_base[1,], 90)
          perp_line_2 <- LearnGeom::Rotate(perp_line, perp_base[2,], 90);

          perp_line_1_ints <- LearnGeom::IntersectLineCircle(perp_line_1, perp_base[1,], (radius * svg_curve_control_multiplier) * edge_size_multiplier);
          perp_line_2_ints <- LearnGeom::IntersectLineCircle(perp_line_2, perp_base[2,], (radius * svg_curve_control_multiplier) * edge_size_multiplier);
        }
        perp_line_1_dists <- apply(perp_line_1_ints, 1, LearnGeom::DistancePoints, c(edge$weighted_midpoint_x, edge$weighted_midpoint_y));
        perp_line_1_dists_max <- which.max(perp_line_1_dists);
        perp_line_1_pt <- perp_line_1_ints[perp_line_1_dists_max,];

        perp_line_2_dists <- apply(perp_line_2_ints, 1, LearnGeom::DistancePoints, c(edge$weighted_midpoint_x, edge$weighted_midpoint_y));
        perp_line_2_dists_max <- which.max(perp_line_2_dists);
        perp_line_2_pt <- perp_line_2_ints[perp_line_2_dists_max,];

        if(path_as == "svg") {
          new_path <- paste0(
             "M ", paste(mp * round(c(pinch_on[1], pinch_on[2]), rnd), collapse = " "),
            " L ", paste(mp * round(c(perp_base[1,1], perp_base[1,2]), rnd), collapse = " "),
            " L ", paste(mp * round(c(perp_base[2,1], perp_base[2,2]), rnd), collapse = " "),
            " Z "
          )
          path$path <- new_path;
          paths <- c(paths, list(path));

          paths <- c(paths, list(list(
            type = "path", opacity = 0.25,
            line = list( width = 1, color = "#000000", opacity = 0.5),
            path = paste0("M", paste(mp * round(c(perp_base[1,1], perp_base[1,2]), rnd), collapse = " "),
                         " L", paste(mp * round(c(perp_base[2,1], perp_base[2,2]), rnd), collapse = " "))
          )))
        }
        else {
          new_path <- as.data.frame(matrix(
            c(mp * round(c(pinch_on[1], pinch_on[2]), rnd),
              mp * round(c(perp_base[1,1], perp_base[1,2]), rnd),
              mp * round(c(perp_base[2,1], perp_base[2,2]), rnd),
              mp * round(c(pinch_on[1], pinch_on[2]), rnd)
            ),
            ncol = 2, byrow = TRUE, dimnames = list(NULL, c("x", "y")))
          )
          path$path <- new_path;
          paths <- c(paths, list(path));
        }
      }
      else {
        stop("edge_end parameter unknown")
      }

      if(edge_arrow == TRUE &&
         (
            edge_arrows_to_show == "both" ||
           # (do.call(paste0("which.", edge_arrows_to_show), list(edge[, c("weight_1", "weight_2")])) == e)
           edges_[label == edge$label, .SD[which.max(value)]]$node_1 == edge$node_1
         )
      ) {
        x_axis <- LearnGeom::CreateLinePoints(c(-10,0), c(10,0))
        perp_line_angle <- LearnGeom::LinesAngles(perp_line, x_axis)
        if(perp_line_angle[1] == 0) {
          mid_point[1] <- mid_point[1] - 0.0001
        }
        arrow_offset <- LearnGeom::MidPoint(mid_point, as.matrix(node))
        arrow_offset_hgt <- CreatePointByDistance(as.matrix(node), arrow_offset, dist = weight * edge_arrow_width);
        arrow_offset_hgt2 <- CreatePointByDistance(as.matrix(node), arrow_offset, dist = weight * (edge_arrow_width*2));

        arrow_offset_line <- MoveLineAlong(arrow_offset[1], arrow_offset[2], perp_line[1])
        arrow_offset_hgt_line <- MoveLineAlong(arrow_offset_hgt[1], arrow_offset_hgt[2], perp_line[1])
        arrow_offset_hgt2_line <- MoveLineAlong(arrow_offset_hgt2[1], arrow_offset_hgt2[2], perp_line[1])
        edge_line_1 <- LearnGeom::CreateLinePoints(perp_base[1,], mid_point);
        edge_line_2 <- LearnGeom::CreateLinePoints(perp_base[2,], mid_point);

        # if(edge_line_1[1] == 0) {
        #   # add for offset
        #   print("ER...Tell Cody you saw me.");
        #   # arrow_int_1 <- LearnGeom::IntersectLines(edge_line_1, arrow_offset_hgt_line);
        #   # arrow_int_2 <- LearnGeom::IntersectLines(edge_line_2, arrow_offset_hgt_line);
        #   # arrow_int2_1 <- LearnGeom::IntersectLines(edge_line_1, arrow_offset_hgt2_line);
        #   # arrow_int2_2 <- LearnGeom::IntersectLines(edge_line_2, arrow_offset_hgt2_line);
        # }
        # else {
          offset_int_1 <- LearnGeom::IntersectLines(edge_line_1, arrow_offset_line);
          offset_int_2 <- LearnGeom::IntersectLines(edge_line_2, arrow_offset_line);
          arrow_int_1 <- LearnGeom::IntersectLines(edge_line_1, arrow_offset_hgt_line);
          arrow_int_2 <- LearnGeom::IntersectLines(edge_line_2, arrow_offset_hgt_line);
          arrow_int2_1 <- LearnGeom::IntersectLines(edge_line_1, arrow_offset_hgt2_line);
          arrow_int2_2 <- LearnGeom::IntersectLines(edge_line_2, arrow_offset_hgt2_line);
        # }

        arr_path <- list(line = list(width = 0));
        if ( edge_arrow_direction == 1 ) {
          new_path <- paste0(
             "M", paste(mp * round(c(arrow_int_1), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_offset), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_int_2), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_int2_2), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_offset_hgt), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_int2_1), rnd), collapse = " "),
            " Z"
          )
        }
        else {
          new_path <- paste0(
             "M", paste(mp * round(c(offset_int_1), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_offset_hgt), rnd), collapse = " "),
            " L", paste(mp * round(c(offset_int_2), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_int_2), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_offset_hgt2), rnd), collapse = " "),
            " L", paste(mp * round(c(arrow_int_1), rnd), collapse = " "),
            " Z"
          )
        }

        arr_path$path <- new_path;
        arr_path$fillcolor <- "#FFFFFF";
        arr_path$line$color <- "#FFFFFF";
        arr_path$line$width <- arrow_halo;
        arr_path$opacity <- 1
        if(!is.null(this_color_hsv)) {
          # add white
          if(edge_arrow_saturation_multiplier < 1) {
            # rgb_s_and_a_equiv_ext <- rgb_white + (rgb_just_s - rgb_white) * (this_color_hsv$alpha * edge_arrow_saturation_multiplier)
            rgb_s_and_a_equiv_ext <- lighten_color(rgb_just_s, this_color_hsv$alpha, edge_arrow_saturation_multiplier);
          }

          # add shade
          else {
            # rgb_s_and_a_equiv_ext <- (rgb_white + (rgb_just_s - rgb_white) * (this_color_hsv$alpha)) * (1 - -(1 - edge_arrow_saturation_multiplier))
            rgb_s_and_a_equiv_ext <- darken_color(rgb_just_s, edge_arrow_saturation_multiplier, this_color_hsv$alpha)
          }

          col_s_and_a_equiv_ext <- grDevices::rgb(rgb_s_and_a_equiv_ext[1,1], rgb_s_and_a_equiv_ext[2,1], rgb_s_and_a_equiv_ext[3,1], maxColorValue = 255)
          arr_path$fillcolor <- col_s_and_a_equiv_ext
        }

        paths <- c(paths, list(arr_path));
      }
    }

    else {
      # cat("Zero edge: ", edge$node_1, ", ", edge$node_2, " - ", weight, "\n");
      # print(edge);
    }
  }
  paths
}


base_plot <- function(
  width = 600, height = width,
  autosize = (is.null(width) && is.null(height)),
  max_axis_marker = 3,
  title = "ENA Plot", ...
) {
  p <-
    plotly::plot_ly(
      mode = "markers+lines", type = "scatter",
      width = width, height = height
    )
  ;

  axis_list <- list(
    type = "linear",
    showgrid = F,
    title = list(text = ""),
    showticklabels = FALSE,
    range = c(-max_axis_marker, max_axis_marker)
  );
  x_axis <- axis_list;
  x_axis$scaleanchor = "y";
  y_axis <- axis_list;

  p <- plotly::layout( p = p, title = title,
    autosize = autosize,
    showlegend = FALSE,
    xaxis = x_axis,
    yaxis = y_axis
  );

  class(p) <- c("enaplot", class(p));

  return(p);
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#' @param y  TBD
#'
#' @return TBD
#' @export
'plot.ena.set' <- function(x, y, ...) {
  p <- base_plot(...)

  attr(p, "model") <- x;

  p
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#' @param y  TBD
#'
#' @return TBD
#' @export
'plot.ena.directed.set' <- function(x, y, ...) {
  p <- base_plot(...)

  attr(p, "model") <- x;

  args <- list(...);
  dimensions <- colnames(as.matrix(x$points))[1:2];
  if(!is.null(args$dimensions)) {
    dimensions <- args$dimensions;
  }
  attr(p, "dimensions") <- dimensions;

  p
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#' @param weighted_nodes TBD
#' @param node_size_multiplier TBD
#' @param node_color TBD
#' @param node_sizes TBD
#' @param node_direction TBD
#' @param self_connections TBD
#' @param self_connection_color TBD
#' @param nodes_include_self TBD
#' @param node_halo TBD
#' @param self_connection_halo TBD
#' @param node_labels TBD
#' @param node_position_multiplier TBD
#' @param sender_direction TBD
#' @param weights TBD
#' @param nodes TBD
#' @param node_saturation_multiplier TBD
#'
#' @return TBD
#' @export
nodes <- function(
  x, ...,
  weighted_nodes = TRUE, node_size_multiplier = 1,
  node_color = "#3E4750", node_sizes = 1, node_direction = 2,
  self_connections = weighted_nodes, self_connection_color = "#000000",
  nodes_include_self = TRUE, node_halo = 0, self_connection_halo = 0,
  node_labels = TRUE, node_position_multiplier = 1, node_saturation_multiplier = 1,

  #
  sender_direction = 1,

  # parameters pulled from model `x` that can be overridden
  weights = NULL, nodes = NULL
) {
  p <- NULL;
  if(is(x, "plotly")) {
    p <- x;
    x <- attr(x = p, which = "model");
    if(is.null(weights)) {
      weights <- attr(p, "edge_weights");
    }
  }
  if(is.null(weights)) {
    weights <- colMeans(as.matrix(x$line.weights$ENA_DIRECTION$response));
  }
  if(is.null(nodes)) {
    nodes <- data.table::copy(x$rotation$nodes);
  }
  else {
    nodes <- data.table::copy(nodes);
  }
  raw_weights <- weights;
  raw_sq_weights_raw <- to_square(raw_weights);
  raw_sq_weights <- raw_weights * node_size_multiplier;

  weights <- abs(weights);

  dimensions <- attr(p, "dimensions");

  # if(is.null(scale_edges_from)) {
  #   if(!is.null(model)) {
  #     scale_edges_from <- c(0, max(as.matrix(model$line.weights$ENA_DIRECTION$response)))
  #   }
  #   else {
  #     scale_edges_from <- c(0, max(raw_weights))
  #   }
  # }

  sq_weights_raw <- to_square(weights);
  sq_weights <- sq_weights_raw * node_size_multiplier;

  if(nodes_include_self == TRUE) {
    node_sizes_raw <- (apply(sq_weights_raw, node_direction, sum));
    node_sizes <- (apply(sq_weights, node_direction, sum));
  }
  else {
    node_sizes_raw <- (apply(sq_weights_raw, node_direction, sum) - diag(sq_weights_raw));
    node_sizes <- (apply(sq_weights, node_direction, sum) - diag(sq_weights));
  }
  node_sizes[node_sizes == 0] <- 0.001

  nodes[, (seq(2, ncol(nodes))) := lapply(.SD, `*`, node_position_multiplier) , .SDcols = (seq(2, ncol(nodes)))];
  dim_indices <- which(colnames(as.matrix(nodes)) %in% dimensions);
  edge_table <- create_edge_matrix(
    NULL, weights = raw_weights, nodes = nodes, direction = sender_direction, dims = dim_indices,
    node_position_multiplier = 1
  );
  nodes_xy <- attr(edge_table, "nodes_xy");

  annotations <- list();
  node_traces <- list();
  if(weighted_nodes) {
    # Node definition
    shape = list(
      type = "circle",
      xanchor = "x",
      yanchor = "y",
      xref = "x",
      yref = "y",
      line = list (color = "#FFFFFF", width = node_halo)
    )

    # ___ Outer nodes ----
    if(length(node_color) == 1) {
      node_color <- rep(node_color, nrow(sq_weights));
    }
    if(self_connections == TRUE) {
      if(length(self_connection_color) == 1) {
        self_connection_color <- rep(self_connection_color, nrow(sq_weights));
      }
      else if(length(self_connection_color) == 2) {
        self_connection_color <- self_connection_color[((raw_weights < 0) * 1) + 1];
      }
    }
    for(i in seq(nrow(sq_weights))) {
      if(node_sizes[i] > 0) {
        shape$line$width = node_halo;
        node <- nodes_xy[i,];
        node_radius <- node_sizes[i] / 2;
        edge_line <- edge_fun(rbind(as.matrix(node),c(0,0)), fun = LearnGeom::CreateLinePoints);
        node_pts <- LearnGeom::IntersectLineCircle(edge_line, as.matrix(node), node_radius);
        shape$x0 <- node$x - (node_radius);
        shape$y0 <- node$y - (node_radius);
        shape$x1 <- node$x + (node_radius);
        shape$y1 <- node$y + (node_radius);
        shape$fillcolor <- paste0(node_color[i], alpha_to_hex(node_saturation_multiplier)); #hsv(0, 0, 0.1, 1); #edge_sizes[i]);

        node_traces <- c(node_traces, list(shape));

        if(node_labels == TRUE) {
          annotations <- c(annotations, list(list(
            x = shape$x1,
            y = shape$y1,
            text = node$code,
            xref = "x", yref = "y",
            showarrow = FALSE, arrowhead = 0,
            ax = 0, ay = -60
          )))
        }

        # ___ Self nodes ----
        if(self_connections) {
          shape$line$width = self_connection_halo;
          shape$x0 <- node$x - (diag(sq_weights)[i] / 2);
          shape$y0 <- node$y - (diag(sq_weights)[i] / 2);
          shape$x1 <- node$x + (diag(sq_weights)[i] / 2);
          shape$y1 <- node$y + (diag(sq_weights)[i] / 2);
          shape$fillcolor <- hsv(0, 0, 1, 1);
          node_traces <- c(node_traces, list(shape));

          shape$x0 <- node$x - (diag(sq_weights)[i] / 2);
          shape$y0 <- node$y - (diag(sq_weights)[i] / 2);
          shape$x1 <- node$x + (diag(sq_weights)[i] / 2);
          shape$y1 <- node$y + (diag(sq_weights)[i] / 2);

          this_color_hsv <- as.list(t(grDevices::rgb2hsv(grDevices::col2rgb(self_connection_color[i]))));
          names(this_color_hsv) <- c("h", "s", "v");
          this_color_hsv$alpha <- diag(sq_weights_raw)[i];
          shape$fillcolor <- do.call(grDevices::hsv, this_color_hsv); #hsv(1, 1, 1, edge_sizes[i]);
          node_traces <- c(node_traces, list(shape));
        }
      }
    }

    attr(x = p, which = "annotations") <- c(attr(x = p, which = "annotations"), annotations);
    attr(x = p, which = "shapes") <- c(attr(x = p, which = "shapes"), node_traces);
  }

  # __ Non-weighted Nodes ----
  else {
    nodes_xy$size <- 15;
    p <- plotly::add_trace(p = p, data = nodes_xy,
      x = ~x, y = ~y,
      text = ~code,
      type = "scatter",
      mode = "markers+text",
      textposition = "bottom center",
      name = "Nodes",
      marker = list(
        sizemode = "diameter",
        size = ~size,
        color = "black",
        line = list(width = 0)
      )
    );
  }

  return(p);
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#' @param show_edge_center TBD
#' @param units TBD
#' @param edge_color TBD
#' @param edge_end TBD
#' @param desaturate_edges_by TBD
#' @param lighten_edges_by TBD
#' @param multiplier TBD
#' @param edge_size_multiplier TBD
#' @param edges_behind_nodes TBD
#' @param sender_direction TBD
#' @param scale_edges_to TBD
#' @param scale_edges_from TBD
#' @param edge_arrow TBD
#' @param edge_arrow_offset TBD
#' @param edge_arrow_width TBD
#' @param edge_arrows_to_show TBD
#' @param edge_arrow_saturation_multiplier TBD
#' @param fake_alpha TBD
#' @param edge_halo TBD
#' @param edge_halo_multiplier TBD
#' @param arrow_halo TBD
#' @param edge_arrow_direction TBD
#' @param weights TBD
#' @param nodes TBD
#' @param node_position_multiplier TBD
#'
#' @return TBD
#' @export
edges <- function(
  x, ...,
  show_edge_center = FALSE, units = NULL,
  edge_color = c("#FF0000","#0000FF"), edge_end = "outward",
  desaturate_edges_by = sqrt, lighten_edges_by = desaturate_edges_by,
  multiplier = 1,
  edge_size_multiplier = multiplier, edges_behind_nodes = TRUE, sender_direction = 1,
  scale_edges_to = c(0,1), scale_edges_from = NULL,
  edge_arrow = TRUE, edge_arrow_offset = 2, edge_arrow_width = 0.1, edge_arrows_to_show = "max",
  edge_arrow_saturation_multiplier = 1.1, fake_alpha = TRUE, edge_halo = 0.5, edge_halo_multiplier = 1.1,
  arrow_halo = 0, edge_arrow_direction = 2, node_position_multiplier = 1,

  # parameters pulled from model `x` that can be overridden
  weights = NULL, nodes = NULL
) {
  .SD <- NULL;

  p <- NULL;
  if(is(x, "plotly")) {
    p <- x;
    x <- attr(x = p, which = "model");
  }
  if(is.null(weights)) {
    weights <- colMeans(as.matrix(x$line.weights$ENA_DIRECTION$response));
  }
  else if (!is.numeric(weights)) {
    weights <- colMeans(as.matrix(weights[ENA_DIRECTION == 'response',]));
  }
  if(is.null(nodes)) {
    nodes <- data.table::copy(x$rotation$nodes);
  }
  else {
    nodes <- data.table::copy(nodes);
  }
  nodes[, (seq(2, ncol(nodes))) := lapply(.SD, `*`, node_position_multiplier) , .SDcols = (seq(2, ncol(nodes)))];
  raw_weights <- weights;
  raw_sq_weights_raw <- to_square(raw_weights);
  raw_sq_weights <- raw_weights * multiplier;

  weights <- abs(weights);

  if(is.null(scale_edges_from)) {
    if(!is.null(model)) {
      scale_edges_from <- c(0, max(as.matrix(x$line.weights$ENA_DIRECTION$response)))
    }
    else {
      scale_edges_from <- c(0, max(raw_weights))
    }
  }

  sq_weights_raw <- to_square(weights);
  sq_weights <- sq_weights_raw * multiplier;

  edge_table <- create_edge_matrix(NULL, weights = raw_weights, nodes = nodes, direction = sender_direction);
  nodes_xy <- attr(edge_table, "nodes_xy");

  edge_path_list <- list();
  nodes_xy <- attr(edge_table, "nodes_xy");
  node_combinations <- attr(edge_table, "node_combinations");

  edge_path_list <- edge_paths(
    edge_table, edge_color = edge_color, edge_end = edge_end,
    desaturate_edges_by = desaturate_edges_by, lighten_edges_by = lighten_edges_by,
    edge_size_multiplier = edge_size_multiplier,
    scale_edges_to = scale_edges_to, scale_edges_from = scale_edges_from,
    edge_arrow = edge_arrow, edge_arrow_offset = edge_arrow_offset,
    edge_arrow_width = edge_arrow_width, edge_arrow_saturation_multiplier = edge_arrow_saturation_multiplier,
    fake_alpha = fake_alpha, edge_halo = edge_halo, edge_arrows_to_show = edge_arrows_to_show,
    arrow_halo = arrow_halo, edge_halo_multiplier = edge_halo_multiplier,
    sender_direction = sender_direction,
    edge_arrow_direction = edge_arrow_direction
  );

  if(show_edge_center) {
    p <- plotly::add_markers(p = p, data = edge_table, x = ~weighted_midpoint_x, y = ~weighted_midpoint_y, marker = list(color = "black"), name = ~label)
    p <- plotly::add_markers(p = p, data = edge_table, x = ~midpoint_x, y = ~midpoint_y, marker = list(color = "black"), name = ~label)
  }

  # p <- plotly::layout(p = p, shapes = edge_path_list);
  attr(x = p, which = "shapes") <- c(attr(x = p, which = "shapes"), edge_path_list);
  attr(x = p, which = "edge_weights") <- raw_weights;

  return (p);
}

unit_vectors <- function(points, dims = c(1,2)) {
  if(is(points, "list")) {
    meta_cols <- which(sapply(points[[1]], is, "ena.metadata"))
    dim_cols <- which(sapply(points[[1]], is, "ena.dimension"))[dims]
    dim_col_names <- colnames(points[[1]])[dim_cols]
  }
  else {
    meta_cols <- which(sapply(points, is, "ena.metadata"))
    dim_cols <- which(sapply(points, is, "ena.dimension"))[dims]
    dim_col_names <- colnames(points)[dim_cols]
  }

  merge_by = c("ENA_UNIT")
  if("_GRP" %chin% colnames(points)) {
    dim_col_names <- c("_GRP", dim_col_names);
    merge_by = c(merge_by, "_GRP");
  }

  from_rows <- points[ENA_DIRECTION == "ground", c("ENA_UNIT", dim_col_names), with = FALSE]
  to_rows <- points[ENA_DIRECTION == "response", c("ENA_UNIT", dim_col_names), with = FALSE]

  sd_cols <- paste(rep(dim_col_names,2), c(rep("from",2), rep("to",2)), sep = ".");
  if(nrow(from_rows) > 0) {
    y <- merge(from_rows, to_rows, by = merge_by, suffixes = c(".from", ".to"));
    y[, distance := {
      LearnGeom::DistancePoints(c(.SD[[sd_cols[1]]], .SD[[sd_cols[2]]]), c(.SD[[sd_cols[3]]], .SD[[sd_cols[4]]]))
    }, .SDcols = c(sd_cols), by = 1:nrow(y)];
    y
  }
  else {
    to_rows;
  }
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#' @param units_as_vectors TBD
#' @param unit_vectors_towards TBD
#' @param mean_vector_width TBD
#' @param mean_vector_arrow_size TBD
#' @param unit_vector_width TBD
#' @param unit_vector_arrow_size TBD
#' @param show_points TBD
#' @param point_shape TBD
#' @param dynamic_response_point_size TBD
#' @param show_mean TBD
#' @param mean_value TBD
#' @param points_color TBD
#' @param saturate_vectors_by TBD
#' @param point_position_multiplier TBD
#' @param distance_scaled_by TBD
#' @param with_lines TBD
#' @param with_ci TBD
#' @param points TBD
#'
#' @return TBD
#' @export
units <- function(
  x, ...,
  units_as_vectors = FALSE, unit_vectors_towards = "response",
  mean_vector_width = 5, mean_vector_arrow_size = 0.5,
  unit_vector_width = 3, unit_vector_arrow_size = 0.7,
  show_points = TRUE, point_shape = "circle",
  dynamic_response_point_size = FALSE,
  show_mean = TRUE,
  mean_value = NULL,
  points_color = "#FF0000",
  saturate_vectors_by = 0.2,
  point_position_multiplier = 1,
  distance_scaled_by = function(x) { scales::rescale(x, to = c(0.3, 1.5), from = c(0, 2)) },
  with_lines = FALSE,
  with_ci = TRUE,


  # parameters pulled from model `x` that can be overridden
  points = NULL
) {
  p <- NULL;
  if(is(x, "plotly")) {
    p <- x;
    x <- attr(x = p, which = "model");
  }
  if(is.null(points)) {
    points <- x$points;
  }

  point_dim_cols <- which(rENA::find_dimension_cols(points));
  points[,point_dim_cols] <- points[,c(point_dim_cols),with = FALSE] * point_position_multiplier;

  dimensions <- attr(p, "dimensions");
  dim_indices <- which(colnames(as.matrix(points)) %in% dimensions);


  unit_table <- unit_vectors(points, dims = dim_indices); # * scale_points_by;
  has_group <- "_GRP" %chin% colnames(unit_table);

  if(length(unique(points$ENA_DIRECTION)) > 1) {
    dim_cols <- paste(rep(dimensions,2), c(rep("from",2), rep("to",2)), sep = ".");
  }
  else {
    dim_cols <- dimensions;
  }
  if(is.null(mean_value)) {
    # dim_cols <- c("SVD1.from", "SVD2.from", "SVD1.to", "SVD2.to");
    mean_table <- if(has_group) {
      unit_table[, lapply(.SD, mean), .SDcols = dim_cols, by = "_GRP"];
    } else {
      unit_table[, lapply(.SD, mean), .SDcols = dim_cols];
    }
  }
  else {
    browser()
    mean_table <- data.table::data.table(
      SVD1.from = mean_value[1],
      SVD2.from = mean_value[2],
      SVD1.to = mean_value[3],
      SVD2.to = mean_value[4]
    )
  }

  # browser()

  if(length(unique(points$ENA_DIRECTION)) > 1) {
    mean_table[ , c("slope", "intercept", "center.x", "center.y") := {
      l = LearnGeom::CreateLinePoints(
        as.numeric(.SD[,c(dim_cols[1:2]), with = FALSE]),
        as.numeric(.SD[,c(dim_cols[3:4]), with = FALSE])
      );
      cen = LearnGeom::MidPoint(
        as.numeric(.SD[, c(dim_cols[1:2]), with = FALSE]),
        as.numeric(.SD[, c(dim_cols[3:4]), with = FALSE])
      );
      list(slope = l[1], intercept = l[2], center.x = cen[1], center.y = cen[2])
    }, by = 1:nrow(mean_table)]
  }

  rgb_cols <- col2rgb(points_color);
  hsv_cols <- apply(rgb_cols, 2, function(rgb_col) rgb2hsv(rgb_col[1], rgb_col[2], rgb_col[3]) );

  if(show_points) {

    if(length(unique(points$ENA_DIRECTION)) > 1) {
      units_by = if(has_group) c("ENA_UNIT", "_GRP") else c("ENA_UNIT")
      if(has_group) {
        unit_table[, c("ang_diff", "center.x", "center.y", "color") := {
          mt <- mean_table[mean_table$`_GRP` == .BY$`_GRP`,]
          list(
            LearnGeom::Angle(
              as.numeric(mt[, c(dim_cols[3:4]), with = FALSE]),
              as.numeric(mt[, c(dim_cols[1:2]), with = FALSE]),
              as.numeric(.SD[1, c(dim_cols[3:4]), with = FALSE])
            ),
            mt$center.x,
            mt$center.y,
            points_color[.BY$`_GRP`]
          )
        }, by = units_by]
      }
      else {
        unit_table[, c("ang_diff", "center.x", "center.y","color") := {
          list(
            LearnGeom::Angle(as.numeric(mean_table[1,3:4, with = FALSE]), as.numeric(mean_table[1,1:2, with = FALSE]), as.numeric(.SD[1,3:4, with = FALSE])),
            mean_table$center.x,
            mean_table$center.y,
            points_color
          )
        }, by = "ENA_UNIT"];
      }

      mean_table[, c("length") := {
        LearnGeom::DistancePoints(
          as.numeric(.SD[, c("center.x", "center.y"), with = FALSE]),
          as.numeric(.SD[, c(dim_cols[3:4]), with = FALSE])
        )
      }, by = 1:nrow(mean_table)]
    }
    else {
      if(has_group) {
        warning("Colors should be updated.")
      }
      else {
        unit_table$color = points_color;
      }
    }

    if(is.function(saturate_vectors_by)) {
      # saturate_vectors_by(unit_table$ang_diff, abs(unit_table$distance - mean_length))
      browser()
      units_by = if(has_group) c("ENA_UNIT", "_GRP") else c("ENA_UNIT")
      unit_table$ang_diff_scaled <- 1
    }
    else {
      unit_table$ang_diff_scaled <- saturate_vectors_by
    }

    unit_table[, color_adjusted := {
      adjusted_color <- lighten_color(.SD$color, alpha = .SD$ang_diff_scaled)
      grDevices::rgb(adjusted_color[1], adjusted_color[2], adjusted_color[3], maxColorValue = 255)
    }, by = 1:nrow(unit_table)]

    unit_points <- NULL;
    if(units_as_vectors == TRUE) {
      data.table::setorder(unit_table, -"distance")

      if(!is.null(point_shape)) {
        p <- plotly::add_markers(
          p = p,
          data = unit_table, x = ~center.x, y = ~center.y,
          marker = list(color = ~color_adjusted, shape = point_shape)
        );
      }

      arrow_size <- if(dynamic_response_point_size) {
        unit_table$distance_scaled <- distance_scaled_by(unit_table$distance);
        unit_table$distance_scaled
      }
      else {
        unit_vector_arrow_size
      }

      point_towards <- NULL
      if ( unit_vectors_towards == "ground" ) {
        point_towards <- unit_table[, c(dim_cols[1:2]), with = FALSE]
      }
      else {
        point_towards <- unit_table[, c(dim_cols[3:4]), with = FALSE]
      }
      p <- plotly::add_annotations(
        p = p,
        data = unit_table,
        # x = ~SVD1.to, y = ~SVD2.to,
        x = point_towards[[1]], y = point_towards[[2]],
        arrowsize = arrow_size,
        arrowwidth = unit_vector_width,
        xref = "x", yref = "y",
        axref = "x", ayref = "y",
        text = "", showarrow = TRUE,
        ax = ~center.x, ay = ~center.y,
        arrowcolor = ~color_adjusted
      );
    }

    # Not arrows
    else {
      if ( unit_vectors_towards == "ground" ) {
        unit_points <- unit_table[, c(dim_cols[1:2]), with = FALSE]
      }
      else {
        unit_points <- unit_table[, c(which(colnames(unit_table) %in% dim_cols)), with = FALSE]
      }
      p <- plotly::add_markers(
        p = p,
        # data = unit_table, x = ~SVD1.to, y = ~SVD2.to,
        data = unit_table, x = unit_points[[1]], y = unit_points[[2]],
        marker = list(color = ~color, shape = point_shape),
        text = ~ENA_UNIT,
        hovertemplate = paste('(%{x},%{y})', '<b>%{text}</b>')
      )
      if(with_lines == TRUE) {
        if ( unit_vectors_towards == "ground" ) {
          point_towards_x <- c("center.x", dim_cols[1])
          point_towards_y <- c("center.y", dim_cols[2])
        }
        else {
          point_towards_x <- c("center.x", dim_cols[3])
          point_towards_y <- c("center.y", dim_cols[4])
        }
        for( i in 1:nrow(unit_table) ) {
          p <- plotly::add_trace(
            p = p,
            type = "scatter",
            mode = "lines",
            data = data.frame(
              X1 = unlist(unit_table[i, c(point_towards_x), with = FALSE]),
              X2 = unlist(unit_table[i, c(point_towards_y), with = FALSE]),
              row.names = NULL
            ),
            x = ~X1, y = ~X2,
            line = list(
              color = unit_table[i,]$color_adjusted,
              width = unit_vector_width
            )
          )
        }
      }
    }
  }
  if(show_mean){
    mean_table$color <- points_color;
    error = list(
      x = list(color = points_color[1], visible=T, type="data"),
      y = list(color = points_color[1], visible=T, type="data")
    );
    int.values = NULL;
    if(with_ci == TRUE) {
      if(has_group) {
        int.values <- unit_table[, lapply(.SD, function(x) { t.test(x, conf.level = 0.95)$conf.int }), .SDcols = dim_cols, by = "_GRP"];

        error$x$array = unlist(int.values[c(1,3), c(4)]);
        error$y$array = unlist(int.values[c(2,4), c(5)]);
        error$x$color = "black"; #points_color;
        error$y$color = "black"; #points_color;
      } else {
        int.values <- matrix(
          c(
            as.vector(stats::t.test(points[,point_dim_cols[1],with=FALSE], conf.level = 0.95)$conf.int),
            as.vector(stats::t.test(points[,point_dim_cols[2],with=FALSE], conf.level = 0.95)$conf.int)
          ),
          ncol=2, byrow = TRUE
        );
        #error$x$array = int.values[,1] Carl thinks these two lines are not right
        #error$y$array = int.values[,2]
        error$x$array = (int.values[1, 2]-int.values[1, 1])/2 # have to compute radius
        error$y$array = (int.values[2, 2]-int.values[2, 1])/2 # if you use two numbers, it may just use the first number.

      }
    }

    if(units_as_vectors == TRUE) {
      p <- plotly::add_markers(
        p = p,
        data = mean_table,
        x = mean_table$center.x,
        y = mean_table$center.y,
        error_x = error$x, error_y = error$y,
        marker = list(color = ~color, symbol = "square", size = 10)
      );
    }
    else {
      # mean_cols <- dim_cols[seq.int(ifelse(unit_vectors_towards == "ground", 1, 3), length.out = 2)];
      mean_cols <- colnames(unit_points);
      p <- plotly::add_markers(
        p = p,
        data = mean_table,
        # x = mean_table$center.x,
        # y = mean_table$center.y,
        x = mean_table[[mean_cols[1]]],
        y = mean_table[[mean_cols[2]]],
        error_x = error$x, error_y = error$y,
        marker = list(color = ~color, symbol = "square", size = 10)
      );
    }
  }

  return(p);
}

#' Title
#'
#' @param x TBD
#' @param ... TBD
#'
#' @return TBD
#' @export
'print.enaplot' <- function(x, ...) {
  class(x) <- c("plotly", "htmlwidget");

  shapes <- attr(x = x, which = "shapes");
  annotations <- attr(x = x, which = "annotations");
  x <- plotly::layout(p = x, shapes = shapes, annotations = annotations);

  print(x);
}
