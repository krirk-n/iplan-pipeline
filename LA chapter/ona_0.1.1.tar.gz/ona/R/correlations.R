#' Calculate correlations on ONA model
#'
#' @param enaset TBD
#' @param pts TBD
#' @param cts TBD
#' @param dims TBD
#' @param direction TBD
#'
#' @return TBD
#' @export
correlations <- function(enaset, pts = NULL, cts = NULL, dims = c(1:2), direction = "response") {
  if(is.null(pts) || is.null(cts)) {
    rows <- enaset$points$ENA_DIRECTION %in% direction
    pts <- enaset$points[rows, ]
    cts <- enaset$model$centroids[, ]
  }

  pComb = combn(nrow(pts), 2)
  point1 = pComb[1,]
  point2 = pComb[2,]

  points = as.matrix(pts)
  centroids = as.matrix(cts)
  svdDiff = matrix(points[point1, dims] - points[point2, dims], ncol=length(dims), nrow=length(point1))
  optDiff = matrix(centroids[point1, dims] - centroids[point2, dims], ncol=length(dims), nrow=length(point1))

  corrs = as.data.frame(mapply(function(method) {
    sapply(dims, function(dim) {
      cor(as.numeric(svdDiff[,dim]), as.numeric(optDiff[,dim]), method=method)
    });
  }, c("pearson","spearman")))

  return(corrs);
}
