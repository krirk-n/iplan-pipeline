#' Calculate node positions for a directed ena model
#'
#' @param set ena model
#' @param filter_rows logical indicating rows from model points to use
#'
#' @return list with matrix of node.positions and centroids
#'
#' @export
directed_node_optimization <- function(set, filter_rows = rep(TRUE, nrow(set$model$points.for.projection))) {
  # stop("Node optimization isn't implemented yet.")

  points = as.matrix(set$points)[filter_rows, ];
  weights = as.matrix(set$line.weights)[filter_rows, ];
  # positions = directed_node_positions(weights, points, ncol(points));
  # positions = directed_node_positions_with_ground_response_added(weights, points, ncol(points));
  if (length(unique(set$points[filter_rows,]$ENA_DIRECTION)) == 2) {
    positions = directed_node_positions_with_ground_response_added(weights, points, ncol(points));
  }
  else {
    positions = directed_node_positions(weights, points, ncol(points));
  }

  node.positions = positions$nodes;
  rownames(node.positions) = set$enadata$codes;

  return(list("node.positions" = node.positions, "centroids" = positions$centroids))
}
