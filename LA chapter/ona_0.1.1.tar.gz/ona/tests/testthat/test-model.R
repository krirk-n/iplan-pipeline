test_that("create model", {
  rs_dat <- data.table::as.data.table(tma::test_rsdata);
  units.by <- c("Condition", "UserName");
  hoo_rules <- tma::conversation_rules(
    (Condition == UNIT$Condition & GroupName == UNIT$GroupName & UserName == UNIT$UserName)
  );

  code_cols <- names(rs_dat)[15:20];
  ena <-
    tma::contexts(rs_dat, units_by = units.by, hoo_rules = hoo_rules) |>
    tma::accumulate_contexts(codes = code_cols, return.ena.set = FALSE, norm.by = NULL) |>
    model()
  ;

  testthat::expect_equal(nrow(ena$connection.counts), 48)
})
