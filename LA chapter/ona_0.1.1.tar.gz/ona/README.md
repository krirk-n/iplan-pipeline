# ONA

Ordered Network Analysis

## Install CRAN

```
Coming Soon
```

## Install Development Version

```
install.packages("ona", repos = c("https://epistemic-analytics.gitlab.io/qe-packages/ona/cran/", "https://cran.rstudio.org"))
```

