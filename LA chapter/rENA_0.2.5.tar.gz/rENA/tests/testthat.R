library(testthat)
library(rENA)

test_check("rENA")
