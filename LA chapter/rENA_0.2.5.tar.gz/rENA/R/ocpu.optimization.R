ocpu.optimization = function(
  set,
  maxit = 1000
) {

}
