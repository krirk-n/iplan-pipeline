#' Coded Rescushell Chat Data
#'
#' A dataset containing sample chat data from the Rescushell Virtual
#' Internship -- this dataset comes from the the TMA package
"RS.data"
