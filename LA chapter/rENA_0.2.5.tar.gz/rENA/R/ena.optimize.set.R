##
# @title Generate ENA Set
# @description Generate an ENA set from a givent ENA data object
#
#
#
# @export
##
ena.optimize.set <- function(

) {

}
