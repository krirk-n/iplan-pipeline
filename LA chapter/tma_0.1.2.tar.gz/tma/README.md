# TMA for ENA

## Install CRAN

```
Coming Soon
```

## Install Development Version

```
install.packages("tma", repos = c("https://epistemic-analytics.gitlab.io/qe-packages/tma/cran/", "https://cran.rstudio.org"))
```
