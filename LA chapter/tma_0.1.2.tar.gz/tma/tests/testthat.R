library(testthat)
library(tma)

test_check("tma")
