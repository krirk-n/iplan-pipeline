#' Sample Data
#'
#' A dataset containing threads
"test_reddit"

#' Sample Data
#'
#' A dataset containing threads
"test_reddit2"

#' Coded Rescushell Chat Data
#'
#' A dataset containing sample chat data from the Rescushell Virtual
#' Internship
"RS.data"

#' Sample Data
#'
#' A small sample dataset
"test_smalldata"

