color_saturation = function(connections) {
  normalized_range = c(min(abs(connections)), max(abs(connections)));
  return(
    rescale(x=abs(connections), from=normalized_range, to=c(0.2,1))
  );
}

network_color = function(network_element, colors = COLORS_HSV[, 1:2]) {
  if (network_element$connections >= 0) {
    color = colors[,1];
  }
  else {
    color = colors[,2];
  }

  # return(hsv(color[1], network_element$saturation, color[3]));
  return(hsv(color[1], color[2] * network_element$saturation, color[3]));
}

generate_outer_node_shapes = function(nodes, center_node_connections) {
  color = COLORS_HSV[, 1];
  if (is_empty(center_node_connections)) {
    outer_nodes_df = nodes[, .(code, size, x0, x1, y0, y1)][, node_proportions := 1]
  }
  else {
    outer_nodes_df = merge(
       nodes[, .(code, size)]
      ,center_node_connections[, .(sender, connections, x0, x1, y0, y1)]
      ,by.x="code"
      ,by.y="sender"
    )[,node_proportions := (size-abs(connections))/size];
  }

  # outer_node_shapes = outer_nodes_df[, .(
  #    xref = 'x', x0, x1
  #   ,yref = 'y', y0, y1
  #   ,type = 'circle'
  #   ,fillcolor = hsv(color[1], node_proportions, color[3])
  #   ,opacity = 1
  #   ,text = size
  #   ,line = list(width = 1, color = "black")
  # )] %>% split(nodes$code) %>% unname();
  outer_node_shapes <- lapply(outer_nodes_df$code, function(cd) {
    code <- outer_nodes_df[code == cd,]
    list(
         xref = 'x', x0 = code$x0, x1 = code$x1
        ,yref = 'y', y0 = code$y0, y1 = code$y1
        ,type = 'circle'
        ,fillcolor = "black" # hsv(color[1], code$node_proportions, color[3])
        ,opacity = 1
        ,text = code$size
        ,line = list(width = 1, color = "black")
    )
  })
  return(outer_node_shapes);
}

# Default: there is no outer_node_shapes; nodes are plotted just as black dots
generate_node_shapes <- function(
  center_node_connections,
  nodes = NULL,
  node_size_dynamic = FALSE,
  center_diameter = "self",    #c("self", "response", "ground")
  total_diameter = "response", #c("self", "response", "ground")
  colors = COLORS_HSV[, 1:2]
) {
    outer_node_shapes = list();
    if (is_empty(center_node_connections)) {
      outer_node_shapes <- generate_outer_node_shapes(nodes, NULL)
      return (outer_node_shapes)
    }
    else {
      center_node_shapes = list();
      browser()
      for( i in 1:length(center_node_connections$connections) ) {
        row = center_node_connections[i, ];
        center_node_shapes[[i]] = data.table(
           xref = 'x', x0 = row$x0, x1 = row$x1
          ,yref = 'y', y0 = row$y0, y1 = row$y1
          ,type='circle'
          ,fillcolor = network_color(row, colors = colors)
          ,text = abs(row$connections)
          ,hoveron = 'fills'
          ,hoverinfo = 'text'
          #,line = list(color='black', width=3)
        )
      }
      return(append(outer_node_shapes, center_node_shapes));
    }
  # }

}

to_shapes_list = function(shape_row) {
  if (is_empty(shape_row)) { return() };
  shape_list = as.list(shape_row)
  shape_list[['line']] = list(width=1, color='black')
  return(shape_list);
}

triangle_path <- function(send, recv, width, multiplier = 1, adjuster = 600) {
  x0 <- recv$x;
  y0 <- recv$y;
  x1 <- send$x;
  y1 <- send$y;

  slope <- orthogonal_slope(x0, y0, x1, y1);
  adjustment <- adjuster / multiplier;

  sine   <- sin_theta_two_nodes(send, recv);
  cosine <- cos_theta_two_nodes(send, recv);

  half_width <- width / 2;
  width_adj <- half_width / adjustment;

  # x0 = send$x - distance_from_endpoint_center*sin_theta_two_nodes(send, receive);
  # y0 = send$y + distance_from_endpoint_center*cos_theta_two_nodes(send, receive);
  # x1 = send$x + distance_from_endpoint_center*sin_theta_two_nodes(send, receive);
  # y1 = send$y - distance_from_endpoint_center*cos_theta_two_nodes(send, receive);
  path <- paste0("M ", x0, " ", y0, " ",
                 "L ", (x1 + (width_adj * sine)), " ", (y1 - (width_adj * cosine)), " ",
                 "L ", (x1 - (width_adj * sine)), " ", (y1 + (width_adj * cosine)), " ",
                 "Z")

  return(path)
}

create_node_shapes <- function(
  plot,
  nodes,
  colors = COLORS_HSV[, 1:2],
  set = NULL,
  multiplier = 1,
  adjuster = 600
) {
  # Shape definition ----
    shape = list(
      type = "circle",
      xanchor = "x",
      yanchor = "y",
      xref = "x",
      yref = "y",
      fillcolor = "black",
      line = list (color = "black")
    )

  # Generate shapes ----
    shapes = list()
    # browser()
    adjustment <- adjuster / multiplier;
    # nodes$size <- c(0.1066974, 0.1280369, nodes$size[3], 0)
    for(i in 1:nrow(nodes)) {
      node = nodes[i, ];

      # node_color <- node$color;
      this_shape <- shape;
      half_width <- node$size / 2;
      width_adj <- half_width / adjustment;

      this_shape$x0 <- as.numeric(node$x) - width_adj
      this_shape$y0 <- as.numeric(node$y) - width_adj
      this_shape$x1 <- as.numeric(node$x) + width_adj
      this_shape$y1 <- as.numeric(node$y) + width_adj
      shapes[[length(shapes) + 1]] <- this_shape

      if(!is.null(node$inner_size) && node$inner_size > 0) {
        this_shape <- shape;
        node_color <- node$color;
        half_width <- node$inner_size / 2;
        width_adj <- half_width / adjustment;
        this_shape$fillcolor <- node_color;
        this_shape$line$color <- node_color;
        this_shape$x0 <- as.numeric(node$x) - width_adj
        this_shape$y0 <- as.numeric(node$y) - width_adj
        this_shape$x1 <- as.numeric(node$x) + width_adj
        this_shape$y1 <- as.numeric(node$y) + width_adj
        shapes[[length(shapes) + 1]] <- this_shape
      }
    }

  # Return updated plot ----
    # plot <- layout(p = plot, shapes = shapes)
    # return(plot);
    return(shapes);
}

create_edge_shapes = function(
  plot,
  edges, midpoints,
  colors = COLORS_HSV[, 1:2],
  thickness_range = c(ifelse(min(edges$connections) == 0, 0, 0.1), 1),
  opacity = scales::rescale(x=abs(edges$connections), from=c(0,1), to = thickness_range),
  set = NULL,
  multiplier = 1,
  adjustment = 600
) {
  # Setup ----
    # thickness = c(min(abs(edges$connections)), max(abs(edges$connections)));

    # message("Note 5: I think we may want the saturation to be multiplied by color[2]")

  # Hidden point ----
  ### - specifically for use with the legend
    plot = add_trace(
         plot
        ,legendgroup = "network"
        ,type = "scatter"
        ,hoverinfo = NULL
        ,mode = "markers"
        ,name = "Network"
        ,opacity = 1
        ,x = 0
        ,y = 0
        ,marker = list ( color = "#000", size = 0.1 )
    )

  # Edge Shapes ----
    shape = list(
      type = "path",
      xanchor = "x",
      yanchor = "y",
      xref = "x",
      fillcolor = "black",
      yref = "y",
      line = list (color = "black")
    )


    shapes = list()
    data.table::setorder(edges, connections)
    for(i in 1:nrow(edges)) {
      row = edges[i, ];
      edge_color <- network_color(row, colors = colors);
      send <- set$rotation$nodes[code == row$sender]
      recv <- set$rotation$nodes[code == row$receiver];
      mid  <- midpoints[sending %in% c(send$code, recv$code) & receiving %in% c(send$code, recv$code)]
      if(nrow(mid) == 0) {
        midpoint <- list(x = recv$SVD1, y = recv$SVD2);
      } else {
        midpoint <- list(x = mid$midpoint_x, y = mid$midpoint_y);
      }
      # print(row$connections)
      this_shape <- shape;
      this_shape$path <- triangle_path(
        list(x=send$SVD1, y=send$SVD2),
        midpoint,
        width = row$connections,
        multiplier = multiplier,
        adjuster = adjustment
      )
      this_shape$line$color <- edge_color;
      this_shape$fillcolor <- edge_color;
      this_shape$opacity <- opacity[i]
      this_shape$name <- abs(row$connections)
      this_shape$legendgroup = "network"

      shapes[[length(shapes) + 1]] <- this_shape
      # plot = add_trace(
      #    plot
      #   ,fill = 'toself'
      #   ,fillcolor = edge_color
      #   ,legendgroup = "network"
      #   ,hoverinfo = 'text'
      #   ,hoveron = 'fills'
      #   ,marker = list(opacity = 0) # don't plot midpoints
      #   ,mode = "markers"
      #   ,opacity = opacity[i]
      #   ,text = abs(row$connections)
      #   ,name = NULL
      #   ,type = 'scatter'
      #   ,showlegend = FALSE
      #   ,x = as.numeric(row[, grep(x = colnames(row), pattern = "^x_path"), with = FALSE])
      #   ,y = as.numeric(row[, grep(x = colnames(row), pattern = "^y_path"), with = FALSE])
      # )
    }

    # plot <- layout(p = plot, shapes = shapes)

  # Return updated plot ----
    # return(plot);
    return(shapes);
}

plot_centroids = function(plot, centroid_info) {
  for (i in 1:length(centroid_info$x)) {
    color = centroid_info$color[[i]];
    plot = add_trace(
      plot
      , x= centroid_info$x[i]
      , y = centroid_info$y[i]
      , text='centroid'
      , marker = list(
        color = color
      )
    )
  }
  return(plot);
}

plot_directed_points <- function(
  plot, set, units,
  labels = names(units), dimensions = 1:2,
  scale_units = TRUE,
  opacity_range = c(0.25,0.75),
  with_mean = TRUE,
  with_points = TRUE,
  with_ci = TRUE,
  just_vectors = TRUE,
  colors = COLORS_HSV
) {

  for(i in seq(length(units))) {
    # browser()
    point_color_hsv <- colors[, i];
    point_color <- hsv(point_color_hsv[1], point_color_hsv[2], point_color_hsv[3])
    wh_units <- units[[i]]
    is_mean <- length(wh_units) > 1
    resp <- as.matrix(set$points[wh_units & ENA_DIRECTION == "response",])
    grnd <- as.matrix(set$points[wh_units & ENA_DIRECTION == "ground",])

    resp_pts <- resp[, dimensions, drop = FALSE]
    grnd_pts <- grnd[, dimensions, drop = FALSE]
    scaleFactor = 1.0

    if( scale_units == TRUE ) {
      np.min.x = abs(min(as.matrix(set$rotation$nodes)[, dimensions[1]]));
      np.min.y = abs(min(as.matrix(set$rotation$nodes)[, dimensions[2]]));
      rp.min.x = abs(min(as.matrix(set$points)[, dimensions[1]]));
      rp.min.y = abs(min(as.matrix(set$points)[, dimensions[2]]));
      maxMin = abs(max(np.min.x / rp.min.x, np.min.y / rp.min.y));

      np.max.x = abs(max(as.matrix(set$rotation$nodes)[, dimensions[1]]));
      np.max.y = abs(max(as.matrix(set$rotation$nodes)[, dimensions[2]]));
      rp.max.x = abs(max(as.matrix(set$points)[, dimensions[1]]));
      rp.max.y = abs(max(as.matrix(set$points)[, dimensions[2]]));
      maxMax = abs(max(np.max.x / rp.max.x, np.max.y / rp.max.y));
      scaleFactor = min(maxMin, maxMax);
    }
    else if (is.numeric(scale_units)) {
      scaleFactor = scale_units;
    }
    # browser()
    resp_pts <- resp_pts * scaleFactor
    grnd_pts <- grnd_pts * scaleFactor

    pts_df <- data.frame(x = c(grnd_pts[,1], resp_pts[,1]), y = c(grnd_pts[,2], resp_pts[,2]));
    distances <- sapply(seq(nrow(grnd_pts)), function(r) dist(rbind(grnd_pts[r,], resp_pts[r,])));
    arrow_colors <- matrix(rep(point_color_hsv, length(distances)), ncol = 3, byrow = TRUE);

    # arrow_colors[, 2] <- arrow_colors[, 2] * (distances);
    # opacity <- scales::rescale(x = distances, to = c(0, point_color_hsv[2]))
    opacity <- scales::rescale(x = distances, to = c(opacity_range[1], opacity_range[2]))

    # arrow_color_hex <- apply(arrow_colors, 1, function(x) hsv(x[1], x[2], x[3]));
    arrow_color_hex <- sapply(seq(nrow(arrow_colors)), function(i) {
      x <- arrow_colors[i, ];
      hsv(x[1], x[2], x[3], opacity[i])
    });
    if(with_points == TRUE) {
      if(just_vectors == FALSE) {
        plot <- add_markers(
           plot
          ,x = pts_df$x
          ,y = pts_df$y
          ,text = labels[i]
          ,legendgroup = "points"
          ,name = paste0(labels[i], " Points")
          ,marker = list(
             color = point_color
            ,size = ~size * multiplier
            ,sizemode = rep("diameter", nrow(pts_df))
            ,sizeref =  rep(1, nrow(pts_df))
            ,sizemin =  rep(1, nrow(pts_df))
          )
        )
      }
      plot <- add_annotations(
         plot
        ,ax = grnd_pts[,1]
        ,x = resp_pts[,1]
        ,axref = "x"
        ,ay = grnd_pts[,2]
        ,y = resp_pts[,2]
        ,ayref = "y"
        ,showarrow = TRUE
        ,text = ''
        ,xref = 'x'
        ,yref = 'y'
        ,arrowcolor = arrow_color_hex
        ,legendgroup = "points"
      )
    }

    if(with_mean == TRUE && is_mean == TRUE && nrow(grnd_pts) > 1) {
      mean_color <- hsv(point_color_hsv[1], point_color_hsv[2], point_color_hsv[3], alpha = 1.0);
      error = list(
        x = list(color = mean_color, visible=T, type="data"),
        y = list(color = mean_color, visible=T, type="data")
      );
      int.values = NULL;
      if(with_ci == TRUE) {
        int.values = matrix(
          c(
            # as.vector(stats::t.test(grnd_pts[,1], conf.level = 0.95)$conf.int),
            # as.vector(stats::t.test(grnd_pts[,2], conf.level = 0.95)$conf.int),
            as.vector(stats::t.test(resp_pts[,1], conf.level = 0.95)$conf.int),
            as.vector(stats::t.test(resp_pts[,2], conf.level = 0.95)$conf.int)
          ),
          # ncol=4
          ncol=2
        );
        error$x$array = int.values[, 1];
        error$y$array = int.values[, 2];
      }

      plot <- add_markers(
         plot
        # ,x = c(mean(grnd_pts[, 1])) #, mean(resp_pts[, 1]))
        # ,y = c(mean(grnd_pts[, 2])) #, mean(resp_pts[, 2]))
        ,x = c(mean(resp_pts[, 1])) #, mean(resp_pts[, 1]))
        ,y = c(mean(resp_pts[, 2])) #, mean(resp_pts[, 2]))
        ,text = paste0(labels[i], " Mean")
        ,marker = list( color = mean_color, symbol = "square" )
        ,error_x = error$x, error_y = error$y,
        ,legendgroup = "means"
        ,name = paste0(labels[i], " Mean")
      )
      plot <- add_annotations(
         plot
        # ,ax = mean(grnd_pts[,1])
        # ,ay = mean(grnd_pts[,2])
        ,x = mean(resp_pts[,1])
        ,y = mean(resp_pts[,2])
        ,axref = "x"
        ,ayref = "y"
        ,showarrow = TRUE
        ,text = ''
        # ,xref = 'x'
        # ,yref = 'y'
        ,arrowcolor = mean_color
        ,legendgroup = "means"
      )

      # response mean for CI
      # error = list(x = list(visible=T, type="data"), y = list(visible=T, type="data"));
      if(with_ci == TRUE){
        error$x$array = int.values[, 3];
        error$y$array = int.values[, 4];
        plot <- add_markers(
           plot
          ,x = c(mean(resp_pts[, 1]))
          ,y = c(mean(resp_pts[, 2]))
          ,text = paste0(labels[i], " Mean")
          ,marker = list( color = mean_color, symbol = "square" )
          ,error_x = error$x, error_y = error$y,
          ,legendgroup = "means"
          ,name = paste0(labels[i], " Mean")
        )
      }
    }
  }
  return(plot)
}

plot_centroid_vectors = function(plot, vector_data) {
  for (i in 1:length(vector_data)) {
    data = vector_data[i] %>% unlist;
    if (data['sending_x'] == data['receiving_x'] && data['sending_y'] == data['receiving_y']) {
      plot = add_trace(
         plot
        ,x = as.numeric(data['sending_x'])
        ,y = as.numeric(data['sending_y'])
        ,text = 'centroid'
        ,marker = list( color = data['color'])
      )
    }
    else {
      plot = add_annotations(
         plot
        ,ax = as.numeric(data['sending_x'])
        ,x = as.numeric(data['receiving_x'])
        ,axref = "x"
        ,ay = as.numeric(data['sending_y'])
        ,y = as.numeric(data['receiving_y'])
        ,ayref = "y"
        ,showarrow = TRUE
        ,text = ''
        ,xref = 'x'
        ,yref = 'y'
        ,arrowcolor = data['color']
      )
    }
  }
  return(plot);
}
