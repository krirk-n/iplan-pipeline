#' Generate directed ENA network
#'
#' @param data data.frame
#' @param ... additional parameters. `accumulated_data` to bypass accumulation, also passed to plot
#' @param optimize_node_positions logical
#' @param plotted_points data.frame
#' @param node_positions data.frame
#' @param print_plot logical
#' @param only_sending_centroid logical
#' @param units TBD
#' @param codes TBD
#' @param conversations TBD
#' @param rotation_on TBD
#' @param optimize_on TBD
#'
#' @return object of type ena.set.directed
#' @export
#'
#' @examples
#'
#' data("RS.data", package = "rENA")
#' rs_code_cols <- colnames(RS.data)[15:20]
#' rs_set_one <- directed_ena(RS.data,
#'    units = c("Condition", "GroupName", "UserName"),
#'    conversations = c("Condition", "GroupName", "ActivityNumber"),
#'    codes = rs_code_cols,
#'    binary = TRUE,
#'    rotation_on = "response",
#'    optimize_on = "response",
#'    windowSize = 4, print_plot = FALSE
#' )
directed_ena = function(
  data, units, conversations, codes,
  ...,
  optimize_node_positions = TRUE,
  only_sending_centroid = FALSE,
  plotted_points = NULL,
  node_positions = NULL,
  rotation_on = "response",
  optimize_on = "response", #c("ground", "response"),
  print_plot = FALSE
) {
  args <- list(...);

  set <- ena.set.directed(data, units, conversations, codes);

  if(!is.null(args$accumulated_data)) {
    data <- args$accumulated_data;
    if(is.data.frame(data$weights[[1]])) {
      adjacency_matrices <- data$weights;
    }
    else {
      adjacency_matrices = format_adjacency_matrix(data$weights);
    }
    set$adjacency_matrix = generate_adjacency_matrix(adjacency_matrices);
  }
  else {
    # This should create set$connection.counts and set$model$row.connection.counts
    set <- directed_accumulation(x = set, units = units, conversations = conversations, codes = codes, ...);
  }

  if(is.null(plotted_points)) {
    set <- directed_model(set, rotation_on = rotation_on, optimize_on = optimize_on, ...);
  }
  else {
    set$points <- plotted_points;
  }

  if(is.null(node_positions)) {
    if(optimize_node_positions == FALSE) {
      set$rotation$nodes = generate_node_coordinates(codes, total_node_connections_calculator(abs((as.square.data.frame(colMeans(as.matrix(set$connection.counts)), names = set$`_function.params`$codes)))))[];
    }
    else {
      # pass abs(adjacency_matrix) in order to account for subtraction matrix
      # set$nodes = generate_node_coordinates(set$codes, NULL);

      # adjacency_matrices <- list(as.square.data.frame(as.numeric(set$connection.counts[1,2:10]), names = set$codes));
      # if (only_sending_centroid) {
      #   set$centroid_coordinates = calculate_centroid(adjacency_matrices);
      # }
      # else {
      #   # NOTE - directed network centroid is midpoint between tail and head of centroid vector
      #   set$centroid_coordinates = calculate_centroid_vectors(adjacency_matrices);
      # }
      # set$rotation$nodes$node_radius <- max_node_diameter(set$rotation$nodes) / 2;


      # if(!is.null(connections_calculator)) {
      #   set$rotation$nodes[, size := sapply(code, connections_calculator)];
      # }
      # else {
        # set$rotation$nodes[, size := 1];
      # }

      # max_size = max(set$rotation$nodes$size);

      # dims <- set$rotation$nodes[, rENA::find_dimension_cols(set$rotation$nodes), with = F];
      # set$rotation$nodes$x0 <- dims[, 1] - node_radius
      # set$rotation$nodes$x1 <- dims[, 1] + node_radius
      # set$rotation$nodes$y0 <- dims[, 2] - node_radius
      # set$rotation$nodes$y1 <- dims[, 2] + node_radius
    }
  }
  else {
    set$nodes <- node_positions;
  }

  if(print_plot == TRUE) {
    set <- plot.ena.directed.set(x = set, ...);
    invisible(set);
  }
  else {
    return(set);
  }
}

#' Create directed ena set object
#'
#' @param data data.frame
#' @param ... Not implemented
#' @param units TBD
#' @param conversations TBD
#' @param codes TBD
#'
#' @return empty list of type ena.set.directed
#' @export
ena.set.directed <- function(data, units, conversations, codes, ...) {
  as.ena.directed.set(
    list(
      meta.data = NULL,
      model = list(
        model.type = "Directed",
        raw.input = data.table::as.data.table(data)
      ),
      rotation = list (
        codes = codes,
        nodes = NULL
      ),
      plots = list(),
      "_function.params" = list(
        units = units,
        conversations = conversations,
        codes = codes
      )
    )
  )
}


