.onLoad <- function(libname, pkgname) {
  utils::globalVariables(c(
    ".", "ENA_DIRECTION", "code", "col2rgb", "combn", "connections", "dist",
    "distance_from_endpoint_center", "hsv", "is", "mass", "name", "node_proportions",
    "outer_size", "prcomp", "proportion", "receiver", "receiving", "reduce", "relative_size",
    "rgb2hsv", "saturation", "sender", "sending", "size", "var", "x", "x0", "x1", "y", "y0", "y1",
    "variable", "node_2", "node_1", "value", "label", "ang_diff", "%<>%", "distance","color_adjusted"
  ))
}

