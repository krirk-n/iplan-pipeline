#' Normalize and optimize a directed accumulation
#'
#' @param x a ena.set.directed with a set of accumulated adjacency matrices
#' @param norm.by TBD
#' @param rotate.using TBD
#' @param rotation.params TBD
#' @param rotation.set TBD
#' @param rotation_on TBD
#' @param optimize_on character, either 'response' or 'ground'
#' @param node.position.method TBD
#' @param center_individually TBD
#' @param center_to_origin TBD
#' @param ... TBD
#'
#' @return ena.set.directed with calcualted points and node positiosn
#' @export
directed_model <- function(
  x, ...,
  norm.by = rENA::fun_sphere_norm,
  node.position.method = directed_node_optimization,
  rotate.using = rENA::ena.svd,
  rotation.params = NULL, rotation.set = NULL,
  rotation_on = c("response"), #response - ground", #response", #c("ground", "response"),
  optimize_on = c("response"), # "ground"),
  center_individually = FALSE,
  center_to_origin = TRUE # ifelse(rotation_on == "response - ground", TRUE, FALSE)
) {
  ##### Generate data.frame with a ground and response row for each unit -----
    ##### > Prep ----
      meta_cols <- which(rENA::find_meta_cols(x$connection.counts))
      code_cols <- which(rENA::find_code_cols(x$connection.counts))

      ground_indices <- as.vector(t(matrix(seq.int(length(x$rotation$codes) ^ 2), ncol = length(x$rotation$codes))))
      response_indices <- seq.int(length(x$rotation$codes) ^ 2)
    ##### > Generate ----
      # df <- data.table::rbindlist(lapply(seq(nrow(x$connection.counts)), function(r) {
      #   row <- x$connection.counts[r, ];
      #   meta <- row[, meta_cols, with = FALSE]
      #   mat <- to_square(as.matrix(row))
      #
      #   ground <- as.vector(t(mat))
      #   response <- as.vector(mat)
      #
      #   # df <- data.frame(matrix(c(ground, response), nrow = 2, byrow = TRUE, dimnames = list(NULL, colnames(row)[find_code_cols(row)])))
      #   # df <- cbind(meta, ENA_DIRECTION = c("ground", "response"), df)
      #   # df
      #   data.table::data.table(meta, ENA_DIRECTION = c("ground", "response"), matrix(c(ground, response), nrow = 2, byrow = TRUE, dimnames = list(NULL, colnames(row)[find_code_cols(row)])))
      # }))
      # setorder(x = df, cols = "ENA_DIRECTION")

      df <- x$connection.counts[rep(1:nrow(x$connection.counts), each = 2)]
      set(
        x = df,
        i = sequence(nrow(x$connection.counts), from = 1, by = 2),
        j = code_cols,
        value = df[sequence(nrow(x$connection.counts), from = 1, by = 2), c(code_cols), with = FALSE][, c(ground_indices), with = FALSE]
      )
      df$ENA_DIRECTION = rep(c("ground", "response"), nrow(x$connection.counts))


    ##### > Set column classes ----
      class(df) <- class(x$connection.counts);
      for(i in colnames(df)) {
        if(i %in% c(names(meta_cols), "ENA_DIRECTION"))
          set(df, j = i, value = rENA::as.ena.metadata(df[[i]]))
        else
          set(df, j = i, value = as.ena.co.occurrence(df[[i]]))
      }

  ##### Model preperation -----
    all_meta_cols <- df[, rENA::find_meta_cols(df), with = FALSE]
    code_columns <- colnames(df)[rENA::find_code_cols(df)];

  ##### Normalize the ground/response adjacency vectors ----
    ### > Normalize adjacency vectors ----
      line.weights <- norm.by(as.matrix(df));

    ### > Classify objects ----
      colnames(line.weights) <- code_columns

      line.weights.dt <- as.data.table(line.weights)
      for (i in seq(ncol(line.weights.dt))) {
        set(line.weights.dt, j = i, value = as.ena.co.occurrence(line.weights.dt[[i]]))
      }

      x$line.weights <- cbind(all_meta_cols, line.weights.dt)
      for(i in which(!find_code_cols(x$line.weights))) {
        set(x$line.weights, j = i, value = rENA::as.ena.metadata(x$line.weights[[i]]))
      }
      class(x$line.weights) <- c("ena.line.weights", class(x$line.weights))


  ##### Center the Normalized data ----
    ### > Center the line.weights ----
      # points.for.projection <- center_data_c(line.weights)
      points.for.projection <- matrix(nrow = nrow(line.weights), ncol = ncol(line.weights))

      if(center_individually == TRUE) {
        points.for.projection[df$ENA_DIRECTION == "ground",] <- center_data_c(line.weights[df$ENA_DIRECTION == "ground",])
        points.for.projection[df$ENA_DIRECTION == "response",] <- center_data_c(line.weights[df$ENA_DIRECTION == "response",])
        points.for.svd = points.for.projection;
      }
      else {
        points.g_r_diff = (
          as.matrix(line.weights[df$ENA_DIRECTION == "response",]) -
          as.matrix(line.weights[df$ENA_DIRECTION == "ground",])
        )
        points.for.svd <- center_data_c(points.g_r_diff);
        # points.for.projection <- line.weights - colMeans(points.g_r_diff);
        points.for.projection <- t(apply(line.weights, 1, function(row) row - colMeans(points.g_r_diff)));
      }

    ### > Classify objects ----
      classify_ <- function(to_classify) {
        colnames(to_classify) <- code_columns;

        # to_classify_dt = data.table::as.data.table(to_classify)
        # for (i in seq(ncol(to_classify_dt))) {
        #   set(to_classify_dt, j = i, value = as.ena.co.occurrence(to_classify_dt[[i]]))
        # }

        to_classify_dt <- rENA::as.ena.matrix(cbind( all_meta_cols, to_classify), "ena.points")
        for(i in colnames(to_classify)) {
          set(to_classify_dt, j = i, value = rENA::as.ena.co.occurrence(to_classify_dt[[i]]))
        }
        return (to_classify_dt)
      }
      x$model$points.for.projection = classify_(points.for.projection);
      x$model$points.for.svd = classify_(points.for.svd);


  ##### SVD -----

    ### > New rotation ----
      if (!is.null(rotate.using) && is.null(rotation.set)) {
        ### >> Row preparation ----
          if(rotation_on %in% c("response", "ground")) {
            rotation_rows <- x$model$points.for.svd$ENA_DIRECTION %in% rotation_on
            points.for.svd = as.matrix(x$model$points.for.svd)[rotation_rows,]
          }
          else if (rotation_on == "response - ground") {
            points.for.svd = as.matrix(x$model$points.for.svd)
          }
          else {
            stop("Unrecognized `rotation_on` value.")
          }

        ### >> Perform SVD on normed, centered data ----
          pcaResults = prcomp(points.for.svd, retx=FALSE, scale=FALSE, center=FALSE, tol=0)

        ### >> Classify Results ----
          colnames(pcaResults$rotation) = c(
            paste('SVD',as.character(1:ncol(pcaResults$rotation)), sep='')
          );

          # rotationSet = ENARotationSet$new(rotation = pcaResults$pca, codes = enaset$codes, node.positions = NULL, eigenvalues = pcaResults$latent)
          rotation = ENARotationSet$new(
            rotation = pcaResults$rotation,
            codes = x$codes,
            node.positions = NULL,
            eigenvalues = pcaResults$sdev^2
          )

          x$rotation.matrix <- data.table::as.data.table(rotation$rotation, keep.rownames = "codes")
          for (i in seq(ncol(x$rotation.matrix))) {
            if(i == 1) {
              set(x$rotation.matrix, j = i, value = as.ena.metadata(x$rotation.matrix[[i]]))
            } else {
              set(x$rotation.matrix, j = i, value = rENA:::as.ena.dimension(x$rotation.matrix[[i]]))
            }
          }
          class(x$rotation.matrix) <- c("ena.rotation.matrix", class(x$rotation.matrix))

          x$rotation$rotation.matrix <- x$rotation.matrix
          x$rotation$eigenvalues <- rotation$eigenvalues;
      }
    ### > Custom rotation provided ----
      else if (!is.null(rotation.set)) {
        if (is(rotation.set, "ena.rotation.set")) {
          x$rotation.matrix <- rotation.set$rotation.matrix
          x$rotation$rotation.matrix <- rotation.set$rotation.matrix
          x$rotation$nodes <- rotation.set$nodes;
          x$rotation$eigenvalues <- rotation.set$eigenvalues
        }
        else {
          stop("Supplied rotation.set is not an instance of ENARotationSet")
        }
      }
      else {
        stop("Unable to find or create a rotation set")
      }

  ##### Generate the rotated points ----
    if (!is.null(x$rotation.matrix)) {
      points <- points.for.projection %*% as.matrix(x$rotation.matrix)
      points.dt <- as.data.table(points)
      for (i in seq(ncol(points.dt))) {
        set(points.dt, j = i, value = rENA:::as.ena.dimension(points.dt[[i]]))
      }
      if(grepl(x = x$model$model.type, pattern = "Trajectory")) {
        x$points <- cbind(x$trajectories, points.dt)
      }
      else {
        x$points <- cbind(all_meta_cols, points.dt)
      }
      x$points <- as.ena.matrix(x$points, "ena.points")
      for(i in which(!find_dimension_cols(x$points))) {
        set(x$points, j = i, value = rENA::as.ena.metadata(x$points[[i]]))
      }
    }
    else {
      stop(paste0("There is no rotation matrix, if you supplied a custom ",
        "rotation.set, be sure it contains a rotation.matrix"))
    }

  ##### Calculate node positions -----
    #  - The supplied methoed is responsible is expected to return a list
    #    with two keys, "node.positions" and "centroids"
    if (exists("rotation") && !is.null(rotation) && is.null(rotation.set)) {
      optimization_rows <- x$model$points.for.projection$ENA_DIRECTION %in% optimize_on
      positions <- node.position.method(x, filter_rows = optimization_rows);

      if (all(names(positions) %in% c("node.positions", "centroids"))) {
        x$rotation$nodes <- data.table::as.data.table(positions$node.positions)
        colnames(x$rotation$nodes) <- colnames(points)
        rownames(x$rotation$nodes) <- x$rotation$codes

        for (i in seq(ncol(x$rotation$nodes))) {
          set(x$rotation$nodes, j = i, value = rENA:::as.ena.dimension(x$rotation$nodes[[i]]))
        }
        x$rotation$nodes <- data.table::data.table(
          code = structure(x$rotation$codes, class = c("code", class(x$rotation$codes))),
          x$rotation$nodes
        )
        class(x$rotation$nodes) = c("ena.nodes", class(x$rotation$nodes))

        x$model$centroids <- data.table::as.data.table(positions$centroids)
        for (i in seq(ncol(x$model$centroids))) {
          set(x$model$centroids, j = i,
            value = rENA:::as.ena.dimension(x$model$centroids[[i]])
          )
        }
        colnames(x$model$centroids) <- colnames(as.matrix(x$rotation.matrix))
        x$model$centroids = cbind(
          data.table(unit = x$model$unit.labels),
          x$model$centroids
        )
        # set(x$model$centroids, j = 1L,
        #   value = as.ena.metadata(x$model$centroids[[1L]])
        # )
        x$model$centroids <- as.ena.matrix(x$model$centroids)
      }
      else {
        stop(paste0("The node position method didn't return back the ",
          "expected objects:\n",
          "\tExpected: c('node.positions','centroids')\n",
          "\tReceived: ", names(positions), sep = ""))
      }
    }
    else if (!is.null(rotation.set)) {
      x$rotation$nodes <- rotation.set$nodes
    }

    if (is.null(x$rotation$nodes)) {
      stop("Unable to determine the node positions either by calculating
                  them using `node.position.method` or using a supplied
                  `rotation.set`")
    }

  # Class setting
    class(x$rotation) <- c("ena.rotation.set", class(x$rotation))

  # Variance ----
    var_rot_data <- var(points)
    diagonal_variance <- as.vector(diag(var_rot_data))
    x$model$variance <- diagonal_variance / sum(diagonal_variance)
    names(x$model$variance) <- colnames(x$rotation$rotation.matrix)[-1]

  # Plot object ----
    x$plots <- list() #default = ena.plot(enadata, ...))
    # class(enadata$model$plot) <- c("ena.plot", class(enadata$model$plot))

  # Additional parameters stored ----
    x$`_function.params`$norm.by <- norm.by

  ##### Center to origin
  if (center_to_origin) {
    point_means <- colMeans(x$points)
    dim_cols <- which(rENA::find_dimension_cols(x$points))
    node_dim_cols <- which(rENA::find_dimension_cols(x$rotation$nodes))
    x$points[, c(dim_cols) := { .SD - lapply(.SD, mean) } , .SDcols = dim_cols]
    x$rotation$nodes[, c(node_dim_cols) := { .SD - as.list(point_means)  }, .SDcols = node_dim_cols ]
  }

  return(x)
}
