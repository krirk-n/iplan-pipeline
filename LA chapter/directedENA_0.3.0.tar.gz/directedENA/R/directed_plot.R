#' Plot a directed ena model
#'
#' @param x ena.set.directed to plot
#' @param ... parameters to pass along - Not yet implemented
#' @param only_sending_centroid logical
#' @param self_connections_in_center logical
#' @param node_size_dynamic logical
#' @param node_color Default: "#000000"
#' @param print_plot logical
#' @param multiplier logical
#' @param multiplier_nodes logical
#' @param multiplier_edges logical
#' @param units List
#' @param dimensions numeric vector of length two
#' @param with_mean logical
#' @param with_points logical
#' @param with_edges logical
#' @param with_nodes logical
#' @param with_ci logical
#' @param with_node_labels logical
#' @param node_center_diameter character, either "self" (default), "response", or "ground"
#' @param node_outer_diameter character, either "self", "response" (default), or "ground"
#' @param node_shape character, see: https://plotly.com/r/reference/#scatter-marker-symbol
#' @param scale_points logcical, default: TRUE
#' @param colors matrix, see directedENA:::COLORS_HSV
#' @param title character, default is empty
#' @param plot_width numeric, default is NULL allowing for dynamic sizing
#' @param plot_height see `plot_width`
#' @param edge_scale  TBD
#' @param opacity_range numeric vector the same length as the number of edges, or a function accepting list returning the numeric vector
#' @param grid  TBD
#'
#' @return ENA model with plot attached
#' @export
#'
#' @examples
#'
#' data("RS.data", package = "rENA")
#' rs_code_cols <- colnames(RS.data)[15:20]
#' rs_set_one <- directed_ena(RS.data,
#'    units = c("Condition", "GroupName", "UserName"),
#'    conversations = c("Condition", "GroupName", "ActivityNumber"),
#'    codes = rs_code_cols,
#'    binary = TRUE,
#'    rotation_on = "response",
#'    optimize_on = "response",
#'    windowSize = 4, print_plot = FALSE
#' )
#' plot(rs_set_one)
#'
#' plot(
#'  rs_set_one,
#'  opacity_range = function(edges) {
#'    scales::rescale(x=abs(edges$connections), to = c(ifelse(min(edges$connections) > 0, 0.01, 0),1));
#'  }
#' )
plot.ena.directed.set <- function(
  # Model options
    x, ...,
    units = NULL,
    dimensions = 1:2,
    print_plot = TRUE,

  # Multipliers for scaling elements
    multiplier = 5,
    multiplier_nodes = multiplier,
    multiplier_edges = multiplier,

  # What to include
    with_mean = FALSE,
    with_points = FALSE,
    with_edges = TRUE,
    with_nodes = TRUE,
    with_node_labels = TRUE,
    with_ci = TRUE,

  # Configuration
    only_sending_centroid = FALSE,  # Deprecate if we remove support for custom centroid_coordinates on `x`
    self_connections_in_center = TRUE,
    node_center_diameter = "self",
    node_outer_diameter = "response",
    node_size_dynamic = TRUE,
    node_shape = "circle",
    node_color = "#000000",

    edge_scale = c(0.5,1),
    scale_points = TRUE,
    opacity_range = NULL,
    colors = NULL,
    title = NULL,
    plot_width = NULL,
    plot_height = plot_width,
    grid = FALSE
) {
  args <- list(...);

  if(is.null(args$print_plot)) {
    args$print_plot <- print_plot;
  }

  if(!is.null(units)) {
    if(inherits(units, "ena.points")) {
      adjacency_matrix <- colMeans(as.matrix(units))
      if(is.null(colors)) {
        colors <- COLORS_HSV[, 1, drop = FALSE]
      }
    }
    else if (inherits(units, "ena.line.weights")) {
      adjacency_matrix <- as.square.data.frame(
        matrix(colMeans(as.matrix(units)),nrow = 1),
        names = x$`_function.params`$codes
      )
      if(is.null(colors)) {
        colors <- COLORS_HSV[, 1, drop = FALSE]
      }
      units = list("Units" = x$line.weights$ENA_UNIT %in% units$ENA_UNIT)
    }
    else {
      adjacency_matrix <- Reduce(`-`, lapply(units, function(u) {
        as.square.data.frame(
          colMeans(
            as.matrix(x$line.weights[u & ENA_DIRECTION == "response"])
          ),
          names = x$`_function.params`$codes
        )
      }))
      if(is.null(colors)) {
        colors <- COLORS_HSV[, seq(length(units)), drop = FALSE]
      }
    }
  }
  else {
    adjacency_matrix <- as.square.data.frame(colMeans(as.matrix(x$line.weights[ENA_DIRECTION == "response",])), names = x$`_function.params`$codes);
    if(is.null(colors)) {
      colors <- COLORS_HSV
    }
    units <- list("Units" = rep(TRUE, nrow(x$line.weights)))
  }
  if(is.character(colors)) {
    colors <- apply(col2rgb(colors), 2, rgb2hsv)
  }

  nodes <- data.table::copy(x$rotation$nodes);
  nodes$size = 1
  node_radius = max_node_diameter(nodes) / 2;
  nodes[, ':=' (relative_size = size / max(size)) ];
  nodes[, ':=' (node_radius = relative_size * node_radius) ];
  all_dim_cols <- find_dimension_cols(nodes);
  dim_cols <- which(all_dim_cols)[dimensions];
  other_cols <- which(!all_dim_cols);
  nodes <- nodes[, .SD, .SDcols = c(names(other_cols), names(dim_cols)), with = TRUE]
  setnames(nodes, old = names(dim_cols), new = c("x", "y"))

  midpoints = generate_midpoints(nodes, abs(adjacency_matrix))[];
  directed_edges = generate_directed_edges(nodes, adjacency_matrix)[];
  sending_receiving = assign_directed_edge_coordinates(directed_edges$sending_receiving, nodes, midpoints, multiplier = multiplier_edges);
  max_axis_marker <- max(abs(nodes$x), abs(nodes$y)) + 0.5;

  # Pulling it all together now, create shapes to plot
  # center_node_connections <- NULL;
  shapes <- NULL
  if(node_size_dynamic) {
    if(!is.null(self_connections_in_center)) {

      if(node_outer_diameter %in% c("ground", "response")) {
        wh_sr_column = c("receiver")
        if(node_outer_diameter == "ground") {
          wh_sr_column = c("sender")
        }

        # browser()
        nodes[, c("size", "outer_size", "inner_size", "shape", "color", "sign") := {
          outer <- sum(directed_edges$sending_receiving[
              directed_edges$sending_receiving[, {
                  total_connections = apply(.SD, 2, function(col) {
                    col == code
                  })
                  if (length(total_connections) == 1) {
                    return(total_connections > 0)
                  } else{
                    rowSums(total_connections) > 0
                  }
              }, .SDcols = c(wh_sr_column)]
            , (connections)]
          );
          inner <- directed_edges$self_connections[sender == as.vector(.BY$code)][, (connections)];
          # multi <- multiplier_nodes;
          this_color <- node_color;
          if(outer >= 0) {
            this_sign <- "positive"
            this_color <- hsv(colors[1,1],colors[2,1], colors[3,1])
          }
          else {
            this_sign <- "negative"
            this_color <- hsv(colors[1,2], colors[2,2], colors[3,2])
          }
          list(
            (abs(outer) + abs(inner)),
            (abs(outer)),
            (abs(inner)),
            node_shape,
            this_color,
            this_sign
          );
        }, by = c("code")]
      }
      else if (node_outer_diameter == "self") {
        nodes[directed_edges$self_connections, outer_size := connections, on = c("code" = "sender")]
      }

      # if (self_connections_in_center) {
      #   center_node_connections = assign_center_node_coordinates(
      #      center_node_connections =  directed_edges$self_connections
      #     ,nodes = nodes
      #   );
      # }
      # else {
      #   center_node_connections = assign_center_node_coordinates(
      #      center_node_connections =  directed_edges$external_connections
      #     ,nodes = nodes
      #   );
      # }
    }

    # shapes <- generate_node_shapes(center_node_connections, nodes, node_size_dynamic = node_size_dynamic, colors = colors);
  }
  else {
    nodes[ ,c("size", "outer_size", "shape", "color") := list((size * multiplier_nodes), 0, node_shape, node_color), by = c("code")]
  }

  # shapes <- lapply(shapes_df, to_shapes_list);
  nodes_dims <- as.matrix(x$rotation$nodes);
  shapes <- list()

  # Create Plot Object -----
    plot <- plot_ly(width = plot_width, height = plot_height) %>%
      layout(
         autosize = TRUE
        ,showlegend = TRUE
        ,title = title
        ,xaxis = list(type = "linear", showgrid = grid, title = "", autorange = TRUE, range = c(-max_axis_marker, max_axis_marker), scaleanchor = "y")
        ,yaxis = list(type = "linear", showgrid = grid, title = "", autorange = TRUE, range = c(-max_axis_marker, max_axis_marker))
      )

  # Allow editing of the plot ----
    # NOTE: This doesn't allow renaming/moving annotations, so may note be worth keeping
    if( !is.null(args$editable) ) {
      plot <- config( p = plot, editable = args$editable )
    }

  # Add node shapes ----
    # TODO: Revisit this, it may not be needed, with the nodes being added below
    if(!is.null(shapes)) {
      plot <- layout( p = plot ) #, shapes = shapes )
    }

  # Add points to plot ----
    # browser()
    plot <- plot_directed_points(
      plot = plot, set = x, units = units,
      with_mean = with_mean, with_points = with_points, with_ci = with_ci,
      scale_units = scale_points,
      colors = colors, ...
    );

  # Add edges ----
    if( is.null(opacity_range) ) {
      opacity_range <- scales::rescale(x=abs(sending_receiving$connections), from=c(0,1), to = edge_scale)
    }
    else if(!is.null(opacity_range) && is.function(opacity_range)) {
      # browser();
      opacity_range <- opacity_range(sending_receiving);
    }
    if(with_edges == TRUE) {
      edge_shapes <- create_edge_shapes(
        plot = plot,
        sending_receiving,
        midpoints = midpoints,
        colors = colors,
        thickness_range = edge_scale,
        opacity = opacity_range,
        set = x,
        multiplier = multiplier_edges
      )
      shapes <- c(shapes, edge_shapes)
    }

  # Add nodes and their labels ------
    if(with_nodes == TRUE) {
      node_shapes <- create_node_shapes(plot = plot, nodes = nodes, colors = node_color, set = x, multiplier = multiplier_nodes)
      shapes <- c(shapes, node_shapes)
      # plot <- add_markers(
      #    p = plot
      #   ,x = ~x
      #   ,y = ~y
      #   ,data = nodes
      #   ,name = "Nodes (response)"
      #   ,legendgroup = "nodes-received"
      #   ,hovertemplate = paste('(%{x}, %{y})<extra></extra>')
      #   ,marker = list(
      #      size = ~abs(size) * multiplier_nodes
      #     ,color = node_color
      #     ,symbol = node_shape
      #     ,opacity = 0.9
      #     ,sizemode = rep("diameter", nrow(nodes))
      #     ,sizeref =  rep(1, nrow(nodes))
      #     ,sizemin =  rep(1, nrow(nodes))
      #    )
      #   ,text = ~code
      #   ,legendgroup = "nodes"
      # ) %>% add_markers(
      #   ,x = ~x
      #   ,y = ~y
      #   ,data = nodes
      #   ,name = "Nodes (self)"
      #   ,legendgroup = "nodes-self"
      #   ,hovertemplate = paste('(%{x}, %{y})<extra></extra>')
      #   ,marker = list(
      #      size = ~abs(inner_size) * multiplier_nodes
      #     ,color = ~color
      #     ,symbol = node_shape
      #     ,opacity = 0.9
      #     ,sizemode = rep("diameter", nrow(nodes))
      #     ,sizeref =  rep(1, nrow(nodes))
      #     ,sizemin =  rep(1, nrow(nodes))
      #    )
      #   ,text = ~code
      #   ,legendgroup = "nodes"
      # )
    }
    if(with_node_labels) {
      plot <- add_text(
         p = plot
        ,x = nodes_dims[, dimensions[1]]
        ,y = nodes_dims[, dimensions[2]]
        ,text = nodes$code
        ,showlegend = FALSE
        ,legendgroup = "nodes"
        ,textposition = "top right"
      )
    }

  # Custom centroids ----
    ## TODO: Deprecate
    if(!is.null(x$centroid_coordinates)) {
      if (only_sending_centroid) {
        plot <- plot_centroids(plot, x$centroid_coordinates);
      }
      else {
        plot <- plot_centroid_vectors(plot, x$centroid_coordinates);
      }
    }

  # Add shapes ----
    plot <- layout(p = plot, shapes = shapes)

  # Save plot to model ----
    x$plots[[length(x$plots) + 1]] <- plot;

  # Finish and return ----
    if(args$print_plot == TRUE) {
      x$`_plot_op` = TRUE
      return(plot);
      # invisible(x);
    }
    else {
      return(x);
    }

}
