#' Significance Test for DirectedENA Points
#'
#' @param x directedENA model
#' @param wh logical vector of length nrow(x$points), TRUE in group1, FALSE in group2
#' @param dim TBD
#'
#' @return list of t.test results
#' @export
significance.test <- function(x, wh, dim = 1) {
  grp1_grnd <- as.matrix(x$points[ wh & ENA_DIRECTION == c("ground"),])[, dim]
  grp1_resp <- as.matrix(x$points[ wh & ENA_DIRECTION == c("response"),])[, dim]
  grp2_grnd <- as.matrix(x$points[ !wh & ENA_DIRECTION == c("ground"),])[, dim]
  grp2_resp <- as.matrix(x$points[ !wh & ENA_DIRECTION == c("response"),])[, dim]

  list(
    ground   = stats::t.test(grp1_grnd, grp2_grnd),
    response =  stats::t.test(grp1_resp, grp2_resp),
    ground_response_group1 =  stats::t.test(grp1_grnd, grp1_resp),
    ground_response_group2 =  stats::t.test(grp2_grnd, grp2_resp),
    ground_response_diff =  stats::t.test(grp1_grnd - grp1_resp, grp2_grnd - grp2_resp)
  )
}
