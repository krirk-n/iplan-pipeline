#' @title drectedENA for modeling directed ENA networks
#' @description directedENA for modeling directed ENA networks
#' @name directedENA
#' @import rENA
#' @import data.table
#' @import plotly
#' @import scales
#' @import LearnGeom
#' @import grDevices
#' @useDynLib directedENA
NULL

# These should likely be parameters to the plot function
MAX_NODE_DIAMETER_SCALAR <- 0.005;

COLORS_HEX <- c("#cc423a", "#56bd7c", "#7FC97F", "#BEAED4", "#FDC086", "#FFFF99", "#BF5B17");
COLORS_RGB <- col2rgb(COLORS_HEX);
COLORS_HSV <- rgb2hsv(COLORS_RGB);

