to_square <- function(x) {
  n <- sqrt(length(x))

  dim(x) <- c(n, n);
  x
}

#' Re-class vector as ena.co.occurrence
#'
#' @param x Vector to re-class
#'
#' @return re-classed vector
#' @export
as.ena.co.occurrence <- function(x) {
  if(is.factor(x)) {
    x = as.character(x)
  }
  class(x) = c("ena.co.occurrence", class(x))
  x
}

#' Title
#'
#' @param x directed ENA model
#'
#' @return matrix
#' @export
as.directed.matrix <- function(x) {
  return(x);
}

#' Title
#'
#' @param x directed ENA model
#' @param names character
#'
#' @return square matrix
#' @export
as.square <- function(x, names = NULL) {
  UseMethod("as.square", x);
}

#' Title
#'
#' @param x directed ENA model
#' @param ... unused
#'
#' @return square matrix
#' @export
as.square.ena.connections <- function(x, ...) {
  x_ <- as.matrix(x);
  square_matrices <- lapply(seq(nrow(x_)), function(y) {
    y <- rENA::as.ena.matrix(to_square(x_[y, ]), "ena.directed.connections")
  })
  square_matrices
}

#' Title
#'
#' @param x directed ENA model
#' @param names character
#'
#' @return square matrix
#' @export
as.square.matrix <- function(x, names = NULL) {
  x_ <- as.data.frame(as.matrix(x))
  as.square(x_)
}

#' Title
#'
#' @param x vector
#' @param names character vector
#'
#' @return square data.frame
#' @export
as.square.data.frame <- function(x, names = NULL) {
  x_ <- as.matrix(x)
  n <- sqrt(length(x_))

  dim(x_) <- c(n, n);
  df <- as.data.frame(x_)

  if(is.null(names)) {
    names <- paste("V", seq(n), sep = "")
  }
  rownames(df) <- colnames(df) <- names;
  df <- rENA::as.ena.matrix(df, "ena.directed.connections")
  df
}

#' Title
#'
#' @param x TBD
#' @param dimension_cols TBD
#' @param unit_cols TBD
#' @param metadata_cols TBD
#' @param code_names TBD
#'
#' @return ena.directed.set
#' @export
as.ena.directed.accumulation <- function(
  x,
  dimension_cols = rENA::find_code_cols(x),
  unit_cols = rENA::find_meta_cols(x),
  metadata_cols = unit_cols,
  code_names = NULL
) {
  for(i in c("dimension_cols", "metadata_cols", "unit_cols")) {
    param <- get(i);
    if(is.null(param)) {
      stop(paste0("`", i , "` must be provided."))
    }
    else if(is.logical(param)) {
      if ( (length(param) < ncol(x)) ||  ( sum(param) < 1 ) ) {
        stop(paste0("If `", i, "` is logical it must be same length as ncol(x) and have at least one TRUE"));
      }
    }
    else if ( length(dimension_cols) < 1) {
        stop(paste0("If `", i, "` isn't logical, then it must be a numeric vector representing columns in `x`"))
    }
  }
  if(!data.table::is.data.table(x)) {
    x <- data.table::as.data.table(x);
  }
  x$ENA_UNIT <- rENA::as.ena.metadata(rENA::merge_columns_c(df = x, cols = colnames(x)[unit_cols], sep = "."));

  metadata <- x[, unique(c("ENA_UNIT", colnames(x)[c(unit_cols, metadata_cols)])), with = FALSE]
  for( i in colnames(metadata) ) {
    data.table::set(metadata, j = i, value = rENA::as.ena.metadata(metadata[[i]]))
  }

  directed.adjacency.vectors <- x[, dimension_cols, with = FALSE]
  for (i in seq_len(ncol(directed.adjacency.vectors))) {
    data.table::set(directed.adjacency.vectors, j = i, value = rENA::as.ena.co.occurrence(as.double(directed.adjacency.vectors[[i]])))
  }
  connection.counts <- data.table::as.data.table(cbind(metadata, directed.adjacency.vectors))
  connection.counts <- rENA::as.ena.matrix(x = connection.counts, "ena.connections")

  row.connection.counts <- data.table::as.data.table(cbind(metadata, directed.adjacency.vectors))
  row.connection.counts <- rENA::as.ena.matrix(row.connection.counts, "row.connections")

  if(is.null(code_names)) {
    code_names <- seq_len(sqrt(length(dimension_cols)))
  }
  x_ <- list(
    meta.data = metadata,
    connection.counts = connection.counts,
    model = list(
      model.type = "Directed",
      row.connection.counts = row.connection.counts,
      raw.input = x
    ),
    rotation = list (
      adjacency.key = adjacency_key_indices(sqrt(length(dimension_cols))),
      codes = code_names,
      nodes = NULL
    ),
    plots = list(),
    "_function.params" = list(
      units = colnames(x)[unit_cols],
      conversations = NULL,
      codes = code_names
    )
  )

  to <- c("ena.directed.set", "ena.set")
  class(x_) <- c(to, class(x_));
  return(x_);
}

#' Convert object to a directed set
#'
#' @param x Object to convert
#'
#' @return list as ena.directed.set
#' @export
as.ena.directed.set <- function(x) {
  to <- c("ena.directed.set")
  if(!inherits(x = x, what = "ena.set")) {
    to <- c(to, "ena.set")
  }
  class(x) <- c(to, class(x));
  return(x);
}

#' Print a directed ena model
#'
#' @param x model to print
#' @param ... not implemented
#' @param plot logical if TRUE, print the plots (default is FALSE)
#'
#' @export
print.ena.set.directed <- function(x, ..., plot = FALSE) {
  x.unclass <- unclass(x)

  if(
    !is.null(x.unclass$`_plot_op`) &&
    x.unclass$`_plot_op` == T
  ) {
    base::print(x.unclass$plots)
  }
  else {
    if(plot == FALSE) {
      x.unclass$plots <- NULL
    }
    base::print(x.unclass)
  }
}


is_empty <- function(x) {
  return(is.null(x) || nrow(x) == 0 || ncol(x) == 0);
}

to_datatable = function(appended_vectors, ncol, nrow) {
  # because we're representing the data as a vector of row vectors, we need to
  # reverse the matrix ncol/nrow and transpose the matrix to get the correct output
  return(data.table::data.table(t(matrix(appended_vectors, nrow = ncol, ncol = nrow))));
}

two_point_weighted_average = function(point_1, point_2, relative_weight) {
  # distance formula from:
  # https://www.khanacademy.org/partner-content/pixar/environment-modeling-2/mathematics-of-parabolas2-ver2/v/weighted-average-two-points
  return((1-relative_weight)*point_1 + (relative_weight*point_2));
}

orthogonal_slope = function(receiver_x, receiver_y, sender_x, sender_y) {
  sender_to_receiver_slope = (sender_y - receiver_y)/(sender_x - receiver_x);
  return(-(1/sender_to_receiver_slope));
}

cos_theta_two_nodes = function (sender, receiver) {
  hypotenus = sqrt((receiver$x - sender$x)^2 + (receiver$y - sender$y)^2);
  adjacent = receiver$x - sender$x;
  return(adjacent/hypotenus);
}

sin_theta_two_nodes = function (sender, receiver) {
  hypotenus = sqrt((receiver$x - sender$x)^2 + (receiver$y - sender$y)^2);
  opposite = receiver$y - sender$y;
  return(opposite/hypotenus);
}

is_vertical_line = function(slope) {
  return(abs(slope) == Inf);
}

is_horizontal_line = function(slope) {
  return(is.nan(slope));
}

adjacency_key_indices = function(len) {
  data.table::data.table(matrix(c(
    rep(1:len, len),
    rep(1:len, each = len)),
    byrow = TRUE, nrow = 2
  ))
}

format_adjacency_matrix = function(raw_data) {
  # node_names = raw_data$node_names;
  # nrows = length(node_names);
  # return(function(raw_matrix) {
  #   matrix = as.data.frame(to_datatable(raw_matrix, nrows, nrows));
  #   colnames(matrix) = rownames(matrix) = node_names;
  #   return(matrix);
  # })
  node_names <- raw_data$node_names;
  node_len <- length(node_names);
  lapply(raw_data$raw_data, function(x) {
    as.data.frame(matrix(x, ncol = node_len, nrow = node_len, dimnames = list(node_names, node_names), byrow = TRUE))
  })
}

raw_coordinates_to_datatable = function(names) {
  nrows = length(names);
  pts.circle <- t(sapply(1:nrows, function(r) c(cos(2*r*pi/nrows), sin(2*r*pi/nrows))))
  colnames(pts.circle) = c('x', 'y');

  # ncols = 3; # 3 columns, nodename, x, and y
  # nodes = to_datatable(raw_data$coordinates, ncols, nrows);
  nodes <- data.table::data.table("name" = names);
  nodes <- cbind(nodes, pts.circle);

  # nodes[, ':=' (x = as.double(x), y = as.double(y))];
  return(nodes);
}

# -------------------------------------
# DATA TRANSFORMATIONS
# -------------------------------------

generate_adjacency_matrix = function(matrices) {
  # guard clauses
  if (length(matrices) > 2) stop("cannot pass this function more than 2 adjacency matrices");
  if (typeof(matrices) != 'list') stop('raw data for adjacency matrix must be in a list')

  # business logic
  if ( length(matrices) == 2 ) {
    # message("Note 4: need to remove reduce, use Reduce?")
    adjacency_matrix = reduce(matrices, `-`);
  }
  else {
    adjacency_matrix = matrices[[1]];
  }

  return(adjacency_matrix);
}

total_node_connections_calculator = function(adjacency_matrix) {
  # return "partially applied" anonymous function in order to generate column values
  return(
    function(node_name) {
      # total node connections should just be sending connections
      total = rowSums(adjacency_matrix[node_name,]);
      # HACK: make sure node is not invisible, set minimum to 1;
      if (total <= 0) { total = 1 };
      return(total);
    }
  )
}

max_node_diameter = function(nodes){
  pts <- as.matrix(nodes)
  plot_area = (max(pts[,1]) - min(pts[,1])) * (max(pts[,2]) - min(pts[,2]));
  # assume that multiplying by the max scalar gives us the area of a square, which should encompass
  # the outer bounds of the largest plotted node.
  # take the square root to get the base of the square, which we will use as the max
  # diameter size, translated to our plot's cartesian plane.
  # all other nodes and edges will be pegged to this max node radius
  return(sqrt(MAX_NODE_DIAMETER_SCALAR * plot_area));
}

generate_node_coordinates = function(codes, connections_calculator = NULL) {
  nodes = raw_coordinates_to_datatable(codes);
  node_radius = max_node_diameter(nodes) / 2;

  if(!is.null(connections_calculator)) {
    nodes[, size := sapply(name, connections_calculator)];
  }
  else {
    nodes[, size := 1];
  }

  max_size = max(nodes$size);
  nodes[, ':=' (relative_size = size / max_size) ];
  nodes[, ':=' (node_radius = relative_size * node_radius) ];

  nodes[, ':=' (
     x0 = x - node_radius
    ,x1 = x + node_radius
    ,y0 = y - node_radius
    ,y1 = y + node_radius
  )];
  return(nodes);
};

# NOTE: technically, these labels are somewhat misleading since this matrix represents
# the total edge weights of both sender and receiver. However, in order to identify
# the weighted midpoint between two nodes, we arbitrarily assign one node to be a
# sender and another to be a receiver.
# This allows us to calculate the proportion of edge weight from the sender to receiver out
# of the total connections between the two nodes.
generate_midpoints = function(nodes, adjacency_matrix) {
  midpoints = data.table::data.table((t(combn(nodes$code, 2))), stringsAsFactors = FALSE);
  colnames(midpoints) = c('sending', 'receiving');

  # browser()
  midpoints[, c("sender_receiver_connections","total_connections", "proportion", "midpoint_x", "midpoint_y") := {
    dim_cols <- which(find_dimension_cols(nodes))
    send <- adjacency_matrix[sending, receiving];
    recv <- adjacency_matrix[receiving, sending];
    prop <- send / (send + recv)
    pts_s <- as.numeric(nodes[code == sending, dim_cols, with = FALSE])
    pts_r <- as.numeric(nodes[code == receiving, dim_cols, with = FALSE])

    mid_x <- two_point_weighted_average( point_1 = pts_s[1], point_2 = pts_r[1], relative_weight = prop);
    mid_y <- two_point_weighted_average( point_1 = pts_s[2], point_2 = pts_r[2], relative_weight = prop);

    list(send, send + recv, prop, mid_x, mid_y);
  }, by = c("sending", "receiving")];

  # this will also remove rows where proportion is NaN
  return(midpoints[proportion != 0]);
}

generate_directed_edges = function(nodes, adjacency_matrix) {
  # directed_edges = data.table(
  #   permutations(n=length(nodes$name), r=2, v=nodes$name, repeats.allowed = TRUE)
  # )
  cols_sr <- c("sender", "receiver");
  directed_edges <- data.table(
    expand.grid("receiver"=nodes$code[order(nodes$code)],
                "sender"=nodes$code[order(nodes$code)], stringsAsFactors = FALSE)
  )[, cols_sr, with = FALSE];
  directed_edges[, connections := adjacency_matrix[sender, receiver], by = cols_sr];
  directed_edges[, saturation := color_saturation(connections)]

  sending_receiving = copy(directed_edges[sender != receiver & abs(connections) > 0]);
  self_connections = copy(directed_edges[sender == receiver]);
  external_connections = copy(directed_edges[sender == receiver]);

  if (!is_empty(external_connections)) {
    # message("Note 1: `external_connections` wasn't saving the mutation, seems questionable. Also, the
    #           resulting connections were all the same.")
    # external_connections %>% mutate(connections = nodes[name == sender]$size - connections);
    external_connections[, connections := {
        nodes[code == sender]$size - connections
      },
      by = sender
    ]
  }
  edges_list <- list(
    sending_receiving = sending_receiving
   ,self_connections = self_connections
   ,external_connections = external_connections
  );

  edges = lapply(edges_list, function(edge_df) {
    edge_df[, relative_size := { abs(connections) / nodes[code == sender]$size }, by = sender];
    edge_df[, distance_from_endpoint_center := { relative_size * nodes[code == sender]$node_radius }, by = sender];

    return(copy(edge_df));
  });

  return(edges);
}

assign_center_node_coordinates = function(center_node_connections, nodes) {
  if(is_empty(center_node_connections)) return(center_node_connections);

  if("distance_from_endpoint_center" %in% colnames(center_node_connections)) {
    setnames(center_node_connections, old = "distance_from_endpoint_center", new = "radius")
  }

  # xy_cols <- colnames(as.matrix(nodes))[1:2];
  xy_cols <- names(which(find_dimension_cols(nodes)))

  center_node_connections <- center_node_connections[nodes,
                                                     c(colnames(center_node_connections), xy_cols),
                                                     on = c(sender = "code"),
                                                     with = FALSE][order(nodes$code)]
  # browser()
  dims <- center_node_connections[, rENA::find_dimension_cols(center_node_connections), with = F];
  center_node_connections$x0 <- dims[, 1] - nodes$node_radius
  center_node_connections$x1 <- dims[, 1] + nodes$node_radius
  center_node_connections$y0 <- dims[, 2] - nodes$node_radius
  center_node_connections$y1 <- dims[, 2] + nodes$node_radius

  center_node_connections
};

calculate_centroid_vectors = function(matrices) {
  # matrices = format_adjacency_matrix(raw_data);

  nodes = raw_coordinates_to_datatable(colnames(matrices[[1]]));
  mass_vectors = list();
  for (i in 1:length(matrices)) {
    # From above, this appears to assume each item in matrices is already a matrix, but it's still a function
    adjacency_matrix = matrices[[i]];
    total_mass = sum(adjacency_matrix);
    node_sending = rowSums(adjacency_matrix);
    all_sending = data.table(name = names(node_sending), mass = as.vector(node_sending));
    sending_mass = merge(all_sending, nodes[, .(name,x,y)], by="name")[, ':=' (
      mass_x = mass*x
      , mass_y = mass*y
    )];
    node_receiving = colSums(adjacency_matrix);
    all_receiving = data.table(name = names(node_receiving), mass = as.vector(node_receiving));
    receiving_mass = merge(all_receiving, nodes[, .(name,x,y)], by="name")[, ':=' (
      mass_x = mass*x
      , mass_y = mass*y
    )];
    color = COLORS_HSV[, i+1]
    sending_x = sum(sending_mass$mass_x) / total_mass;
    sending_y = sum(sending_mass$mass_y) / total_mass;
    receiving_x = sum(receiving_mass$mass_x) / total_mass;
    receiving_y = sum(receiving_mass$mass_y) / total_mass;

    mass_vectors[[i]] = list(
      sending_x = sending_x
      , sending_y = sending_y
      , receiving_x = receiving_x
      , receiving_y = receiving_y
      , color = hsv(color['h'], 0.93, color['v'])
    )
  }
  return(mass_vectors);
}

calculate_centroid = function(raw_data) {
  # matrices = lapply(data$raw_data, format_adjacency_matrix(data));
  matrices = format_adjacency_matrix(raw_data);

  nodes = raw_coordinates_to_datatable(raw_data);
  x_coords = c();
  y_coords = c();
  color = list();
  for (i in 1:length(matrices)) {
    centroid_color = COLORS_HSV[, i+1]
    adjacency_matrix = matrices[[i]];
    node_sending = rowSums(adjacency_matrix);
    total_mass = sum(node_sending);
    all_sending = data.table(name = names(node_sending), mass = as.vector(node_sending));
    node_mass = merge(all_sending, nodes[, .(name,x,y)], by="name")[, ':=' (
      mass_x = mass*x
      , mass_y = mass*y
    )];
    x_coords[i] = sum(node_mass$mass_x) / total_mass;
    y_coords[i] = sum(node_mass$mass_y) / total_mass;
    # #F01186
    color[[i]] = hsv(centroid_color['h'], 0.93, centroid_color['v'])
  }
  return(list(x = x_coords , y = y_coords, color = color));
}

assign_directed_edge_coordinates = function(sending_receiving, nodes, midpoints, multiplier = 1) {
  # message("Note 2: Making a copy to remove DT warning for now") # I can't find the automatic R copy (clm)
  sending_receiving <- copy(sending_receiving);
  # nodes <- copy(nodes);
  # midpoints <- copy(midpoints);
  sr_cols <- c("sender", "receiver")
  colvector <- c("endpoint_coordinates_x", "endpoint_coordinates_y")

  sending_receiving[, (colvector) := {
    midpoint_present_for_nodes <- midpoints[
      (midpoints$sending %in% .SD$sender   & midpoints$receiving %in% .SD$receiver) |
      (midpoints$sending %in% .SD$receiver & midpoints$receiving %in% .SD$sender)
    ];
    if (is_empty(midpoint_present_for_nodes)) {
      list(x = nodes[code == receiver]$x, y = nodes[code == receiver]$y);
    }
    else {
      list(x = midpoint_present_for_nodes$midpoint_x, y = midpoint_present_for_nodes$midpoint_y);
    }
  }, by = sr_cols, .SDcols = sr_cols]

  colvector_tri <- c("triangle_base_coordinates_x0", "triangle_base_coordinates_y0",
                     "triangle_base_coordinates_x1", "triangle_base_coordinates_y1")
  sending_receiving[, (colvector_tri) := {
    send = nodes[code == .SD$sender];
    receive = nodes[code == .SD$receiver];
    slope = orthogonal_slope(receive$x, receive$y, send$x, send$y);
    sine = sin_theta_two_nodes(send, receive);
    cosine = cos_theta_two_nodes(send, receive);
    distance_from_endpoint_center = distance_from_endpoint_center * multiplier;
    x0 = send$x - distance_from_endpoint_center*sin_theta_two_nodes(send, receive);
    y0 = send$y + distance_from_endpoint_center*cos_theta_two_nodes(send, receive);
    x1 = send$x + distance_from_endpoint_center*sin_theta_two_nodes(send, receive);
    y1 = send$y - distance_from_endpoint_center*cos_theta_two_nodes(send, receive);
    if (is_horizontal_line(slope)) {
      y0 = y1 = send$y;
      x0 = send$x + distance_from_endpoint_center;
      x1 = send$x - distance_from_endpoint_center;
    }
    else if (is_vertical_line(slope)) {
      x0 = x1 = send$x;
      y0 = send$y + distance_from_endpoint_center;
      y1 = send$y - distance_from_endpoint_center;
    }
    list(x0 = x0, y0 = y0, x1 = x1, y1 = y1)
  }, by = sr_cols, .SDcols = sr_cols]

  colvector_paths <- c("x_path_ep_1", "x_path_tr_1", "x_path_tr_2", "x_path_ep_2",
                       "y_path_ep_1", "y_path_tr_1", "y_path_tr_2", "y_path_ep_2")
  sending_receiving[, (colvector_paths) := {
    list(
       .SD$endpoint_coordinates_x
      ,.SD$triangle_base_coordinates_x1
      ,.SD$triangle_base_coordinates_x0
      ,.SD$endpoint_coordinates_x
      ,.SD$endpoint_coordinates_y
      ,.SD$triangle_base_coordinates_y1
      ,.SD$triangle_base_coordinates_y0
      ,.SD$endpoint_coordinates_y
    )
  }, by = sr_cols]
  return(sending_receiving[]);
}

