#' Accumulation for Directed Networks
#'
#' @param x object to accumulate
#' @param units character vector of columns to use as units
#' @param conversations character vector of columns to use as conversations
#' @param codes character vector of columns to use as codes
#' @param binary logical TRUE (default) will converat row accumulations to binary
#' @param weight_using TBD
#' @param windowSize numeric integer representing window size
#' @param ... TBD
#'
#' @return ena model object
#' @export
directed_accumulation <- function(
  x,
  units, conversations, codes,
  binary = TRUE, weight_using = NULL,
  windowSize = 4, ...
) {
  #### Prepare input -----
    dat <- NULL
    set <- NULL

    if(inherits(x = x, what = "data.frame")) {
      set <- ena.set.directed(x, units, conversations, codes);
    }
    else if(inherits(x = x, what = "ena.set")) {
      set <- x;
    }
    else {
      stop("`x` must be an existing ena.set.directed or a data.frame or data.table in which to create a set from")
    }

    dat <- data.table::copy(set$model$raw.input);

  #### Calcuate row.connection.counts -----
    all.cols <- c(units, codes)
    new.cols <- paste("V", seq(length(codes) ^ 2), sep = "")
    row.connection.counts <- dat[,
      (new.cols) := accum_stanza_window(df = .SD[, .SD, .SDcols = codes], windowSize = windowSize, binary = binary),
      by = conversations,
      .SDcols = all.cols
    ]
    for(i in new.cols) {
      set(row.connection.counts, j = i, value = as.ena.co.occurrence(row.connection.counts[[i]]))
    }

  #### Set the column classes -----
    for(i in colnames(row.connection.counts)) {
      if(i %in% c(units, conversations))
        set(row.connection.counts, j = i, value = rENA::as.ena.metadata(row.connection.counts[[i]]))
      else if (i %in% c(codes))
        set(row.connection.counts, j = i, value = rENA:::as.ena.code(row.connection.counts[[i]]))
    }
    row.connection.counts <- as.ena.matrix(x = row.connection.counts, "row.connections")

  #### Additional columns added -----
    row.connection.counts$ENA_UNIT <- rENA::as.ena.metadata(rENA::merge_columns_c(df = row.connection.counts, cols = units, sep = "."));

  #### Calculate connection.counts (Sum rows by unit)
    connection.counts <- row.connection.counts[, lapply(.SD, sum), .SDcols = new.cols, by = c("ENA_UNIT", units)]
    for(i in which(colnames(connection.counts) %in% c("ENA_UNIT", units))) {
      set(connection.counts, j = i, value = rENA::as.ena.metadata(connection.counts[[i]]))
    }
    connection.counts <- as.ena.matrix(x = connection.counts, "ena.connections")

  ##### Check weighting of accumulation ----
    if( binary == FALSE && !is.null(weight_using) ) {
      browser()
    }

  #### Store values on the ena.set object -----
    set$connection.counts <- connection.counts;
    set$model$row.connection.counts <- row.connection.counts;

    set$meta.data <- connection.counts[,rENA::find_meta_cols(connection.counts), with = FALSE];
    set$`_function.params`$binary <- binary
    set$`_function.params`$windowSize <- windowSize

  #### Done -----
    return(set)
}
