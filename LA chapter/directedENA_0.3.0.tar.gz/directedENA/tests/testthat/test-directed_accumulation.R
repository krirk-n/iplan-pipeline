describe('directed_accumulation', {
  describe('call-response accumulation', {
    describe('for two units', {
      describe('a single conversation, balanced talk between both units', {
        # setup
        single_balanced_conversation = function() {
          return(data.frame(
            unit=1:2
            , conversation = 1
            , A = c(0,1,0,1)
            , B = c(1,0,1,0)
            , C = c(0,0,0,1)
          ))
        };
        it('calculates the moving stanza window correctly',{
          # Arrange
          expected = t(matrix(c(
            0,0,0,
            2,1,1,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
            , window.forward = TRUE
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          first_row = as.matrix(
            result$model$row.connection.counts[1, code_columns, with = FALSE],
            ncol=3
          );
          dim(first_row) = c(3,3);
          # expect_equal(first_row, expected);
        });
        it("calculates the first unit's total conversation codes correctly",{
          expected = t(matrix(c(
            0,1,0,
            0,1,0,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        it("calculates the second unit's total conversation codes correctly",{
          expected = t(matrix(c(
            1,0,2,
            3,0,2,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        # teardown
        rm(single_balanced_conversation);
      })
    })
  })
  describe('ground-response accumulation', {
    describe('for two units', {
      describe('a single conversation, balanced talk between both units', {
        # setup
        single_balanced_conversation = function() {
          return(data.frame(
            unit=1:2
            , conversation = 1
            , A = c(0,1,0,1)
            , B = c(1,0,1,0)
            , C = c(0,0,0,1)
          ))
        };
        it('calculates the moving stanza window correctly',{
          # Arrange
          expected = t(matrix(c(
            1,0,2,
            2,0,2,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          fourth_row = as.matrix(
            result$model$row.connection.counts[4, code_columns, with = FALSE],
            ncol=3
          );
          dim(fourth_row) = c(3,3);
          expect_equal(fourth_row, expected);
        });
        it("calculates the first unit's total conversation codes correctly",{
          expected = t(matrix(c(
            0,1,0,
            0,1,0,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        it("calculates the second unit's total conversation codes correctly",{
          expected = t(matrix(c(
            1,0,2,
            3,0,2,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_balanced_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        describe('binarizing stanza windows', {
          it('calculates the moving stanza window correctly', {
            expected = t(matrix(c(
              1,0,1,
              1,0,1,
              1,0,0
            ), nrow = 3));
            # Act
            result = directed_accumulation(
              single_balanced_conversation()
              , units = "unit"
              , conversations = "conversation"
              , codes = LETTERS[1:3]
              , binary = TRUE
              , windowSize = 4
            )
            # Assert
            code_columns = paste("V", seq(9), sep = "");
            fourth_row = as.matrix(
              result$model$row.connection.counts[4, code_columns, with = FALSE],
              ncol=3
            );
            dim(fourth_row) = c(3,3);
            expect_equal(fourth_row, expected);
          })
          it("calculates the first unit's total conversation codes correctly", {
            expected = t(matrix(c(
              0,1,0,
              0,1,0,
              0,0,0
            ), nrow = 3));
            # Act
            result = directed_accumulation(
              single_balanced_conversation()
              , units = "unit"
              , conversations = "conversation"
              , codes = LETTERS[1:3]
              , binary = TRUE
              , windowSize = 4
            )
            # Assert
            code_columns = paste("V", seq(9), sep = "");
            conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
            dim(conversation_counts) = c(3,3);

            expect_equal(conversation_counts, expected);
          })
          it("calculates the second unit's total conversation codes correctly", {
            expected = t(matrix(c(
              1,0,1,
              2,0,1,
              1,0,0
            ), nrow = 3));
            # Act
            result = directed_accumulation(
              single_balanced_conversation()
              , units = "unit"
              , conversations = "conversation"
              , codes = LETTERS[1:3]
              , binary = TRUE
              , windowSize = 4
            )
            # Assert
            code_columns = paste("V", seq(9), sep = "");
            conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
            dim(conversation_counts) = c(3,3);

            expect_equal(conversation_counts, expected);
          })
        });
        # teardown
        rm(single_balanced_conversation);
      });
      describe('when given multiple conversations', {
        # setup
        multiple_conversations = function() {
          return(data.frame(
            unit=1:2
            , conversation=c(1,1,1,1,2,2,2,2)
            , A = c(0,1,0,1,1,0,1,0)
            , B = c(1,0,1,0,1,0,1,0)
            , C = c(0,0,0,1,0,0,0,1)
          ));
        }
        it("correctly accumulates unit one's connections across all conversations",{
          expected = t(matrix(c(
            1,4,0,
            3,2,0,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            multiple_conversations()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("correctly accumulates unit two's connections across all conversations", {
          expected = t(matrix(c(
            1,0,4,
            3,0,4,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            multiple_conversations()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        # teardown
        rm(multiple_conversations);
      });
      describe('an empty conversation (no codes)', {
        # setup
        empty_conversation = function() {
          return(data.frame(
            unit = c(1,2,1,2)
            , conversation = 1
            , A = 0
            , B = 0
            , C = 0
          ))
        }
        it('returns zeroed matrices for the final row', {
          expected = matrix(0, ncol = 3, nrow = 3);
          # Act
          result = directed_accumulation(
            empty_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          fourth_row = as.matrix(
            result$model$row.connection.counts[4, code_columns, with = FALSE],
            ncol=3
          );
          dim(fourth_row) = c(3,3);
          expect_equal(fourth_row, expected);
        });
        it("returns zeroed matrices for unit one's conversation", {
          expected = matrix(0, ncol = 3, nrow = 3);
          # Act
          result = directed_accumulation(
            empty_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        it("returns zeroed matrices for unit two's conversation", {
          expected = matrix(0, ncol = 3, nrow = 3);
          # Act
          result = directed_accumulation(
            empty_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        });
        # teardown
        rm(empty_conversation);
      });
      describe('when one unit is only in the ground and the other responding', {
        # setup
        only_responding = function() {
          return(data.frame(
            unit=c(1,2,1,1,2,1,1,2)
            , conversation=1
            , A = c(1,0,0,0,1,0,0,0)
            , B = c(0,0,0,0,0,0,1,1)
            , C = c(0,1,0,1,0,0,0,0)
          ))
        }
        it("accumulates correctly for responding unit", {
          expected = t(matrix(c(
            0,0,1,
            0,1,0,
            1,0,0
          ), nrow = 3));

          # Act
          result = directed_accumulation(
            only_responding()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 2
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          # browser();
          expect_equal(conversation_counts, expected);
        })
        it("accumulates correctly for ground unit", {
          expected = matrix(0, ncol = 3, nrow = 3);

          # Act
          result = directed_accumulation(
            only_responding()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 2
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          # browser();
          expect_equal(conversation_counts, expected);
        })
      })
    });
    describe('for one unit', {
      describe('for one conversation', {
        it('accumulates the conversation correctly', {
          # Arragne
          data = data.frame(
            unit=1
            , conversation = 1
            , A = c(0,1,0,1)
            , B = c(1,0,1,0)
            , C = c(0,0,0,1)
          )
          expected = t(matrix(c(
            1,1,2,
            3,1,2,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            data
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          # Assert
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          expect_equal(conversation_counts, expected);
        })
      });
    });
    describe('for more than two units', {
      describe('one conversation', {
        # setup
        single_conversation = function() {
          return(data.frame(
            unit = 1:8
            , conversation = 1
            , A = c(0,1,0,1,1,0,1,0)
            , B = c(1,0,1,0,1,0,1,0)
            , C = c(0,0,0,1,0,0,0,1)
          ));
        }
        it("accumulates unit one's codes correctly",{
          expected = matrix(0, ncol = 3, nrow = 3);
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[1, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit two's codes correctly",{
          expected = t(matrix(c(
            0,0,0,
            1,0,0,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[2, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit three's codes correctly",{
          expected = t(matrix(c(
            0,1,0,
            0,1,0,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[3, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit four's codes correctly",{
          expected = t(matrix(c(
            1,0,2,
            2,0,2,
            1,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[4, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit five's codes correctly",{
          expected = t(matrix(c(
            2,3,0,
            2,1,0,
            1,1,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[5, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit six's codes correctly",{
          expected = matrix(0, nrow = 3, ncol = 3);
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[6, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit seven's codes correctly",{
          expected = t(matrix(c(
            2,3,0,
            2,1,0,
            1,1,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[7, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        it("accumulates unit eight's codes correctly",{
          expected = t(matrix(c(
            0,0,2,
            0,0,2,
            0,0,0
          ), nrow = 3));
          # Act
          result = directed_accumulation(
            single_conversation()
            , units = "unit"
            , conversations = "conversation"
            , codes = LETTERS[1:3]
            , binary = FALSE
            , windowSize = 4
          )
          code_columns = paste("V", seq(9), sep = "");
          conversation_counts = as.matrix(result$connection.counts[8, code_columns, with = FALSE]);
          dim(conversation_counts) = c(3,3);

          # Assert
          expect_equal(conversation_counts, expected);
        });
        # teardown
        rm(single_conversation);
      });
    });
  });
})
