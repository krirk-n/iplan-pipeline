red <- "#cc423a"
blue <- "#009BE0"
colors = c(red, blue)
data = read.csv(system.file(package = "directedENA", "extdata/TADMUSCoded.csv"));

codes = c("SeekingInformation","DetectIdentify","TrackBehavior","DefensiveOrders","DeterrentOrders")
units = c('COND', 'Team', 'MacroRole', 'Speaker');
conversations = c('Team', 'Scenario');
rotation_on = 'ground';
test_that("just ground and response optimization", {
  optimize_on = c('ground', 'response');

  # speaker_set = ena.set.directed(data, units, conversations, codes);

  speaker_set_both = directed_accumulation(x = data, units = units, conversations = conversations, codes = codes);
  testthat::expect_silent(directed_model(speaker_set_both, rotation_on = rotation_on, optimize_on = optimize_on))
  # speaker_set = directed_model(speaker_set, rotation_on = rotation_on);
  #
  # speaker_set = directed_ena(
  #   data,
  #   units = units,
  #   conversations = conversations,
  #   codes = codes,
  #   binary = TRUE,
  #   windowSize = 5,
  #   print_plot = FALSE,
  #   meta.data = c('MacroRole'),
  #   rotate_on='response',
  #   optimize_on=c('ground')
  # );

})

test_that("just ground optimization", {
  optimize_on = 'ground';

  # speaker_set = ena.set.directed(data, units, conversations, codes);

  speaker_set = directed_accumulation(x = data, units = units, conversations = conversations, codes = codes);
  testthat::expect_silent(directed_model(speaker_set, rotation_on = rotation_on, optimize_on = optimize_on))
  # speaker_set = directed_model(speaker_set, rotation_on = rotation_on);
  #
  # speaker_set = directed_ena(
  #   data,
  #   units = units,
  #   conversations = conversations,
  #   codes = codes,
  #   binary = TRUE,
  #   windowSize = 5,
  #   print_plot = FALSE,
  #   meta.data = c('MacroRole'),
  #   rotate_on='response',
  #   optimize_on=c('ground')
  # );

})
