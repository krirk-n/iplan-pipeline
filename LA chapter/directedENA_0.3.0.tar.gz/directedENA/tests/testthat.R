library(testthat)
library(directedENA)

test_check("directedENA")
